#!/usr/bin/env python3
"""电子拾音器课堂：仅用于可信课堂局域网的无依赖教师服务。"""
from __future__ import annotations

import argparse
import csv
import io
import ipaddress
import json
import math
import os
from pathlib import Path
import re
import secrets
import shutil
import signal
import socket
import ssl
import sys
import tempfile
import threading
import time
import urllib.parse
import wave
from collections import OrderedDict, deque
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


VERSION = "1.0"
GITHUB_ORIGIN = "https://mutiwangn.github.io"
STUDENT_URL = GITHUB_ORIGIN + "/AI-html/四上3.3声音的高低_学生端/"
ID_RE = r"[A-Za-z0-9_-]{8,64}"
INPUT_GAINS = {1, 4, 8, 16, 32}


@dataclass(frozen=True)
class Limits:
    max_students: int = 64
    history_per_student: int = 3600
    max_waveform_samples: int = 2048
    max_json_bytes: int = 65536
    max_wav_bytes: int = 6 * 1024 * 1024
    max_recording_bytes: int = 128 * 1024 * 1024
    max_recording_seconds: float = 30.1
    max_workers: int = 32
    max_uploads: int = 4

    def public(self):
        return {
            "maxStudents": self.max_students,
            "historyPerStudent": self.history_per_student,
            "maxWaveformSamples": self.max_waveform_samples,
            "maxWavBytes": self.max_wav_bytes,
            "maxRecordingSeconds": 30,
            "maxRecordingBytes": self.max_recording_bytes,
        }


class ApiError(Exception):
    def __init__(self, status, code, message):
        super().__init__(message)
        self.status, self.code, self.message = status, code, message


def clean_origin(value):
    """Accept origins, never arbitrary paths, user info, or credentials."""
    try:
        parsed = urllib.parse.urlsplit(value)
        if (parsed.scheme not in {"http", "https"} or not parsed.hostname
                or parsed.username is not None or parsed.password is not None
                or parsed.path not in {"", "/"} or parsed.query or parsed.fragment):
            raise ValueError
        port = parsed.port
        host = parsed.hostname.lower()
        if ":" in host:
            host = "[" + host + "]"
        if port is not None and port != (443 if parsed.scheme == "https" else 80):
            host += ":" + str(port)
        return parsed.scheme + "://" + host
    except (ValueError, AttributeError):
        raise ValueError("地址必须是完整的 http(s) 源地址，不含路径、账号或参数。")


def finite_number(value, name, low, high, nullable=False):
    if value is None and nullable:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ApiError(400, "invalid_frame", name + "必须是数值。")
    if not math.isfinite(value) or not low <= value <= high:
        raise ApiError(400, "invalid_frame", name + "超出允许范围。")
    return value


def csv_cell(value):
    text = str(value)
    if text.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")):
        return "'" + text
    return text


def iso_time(timestamp):
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(timestamp))


class ClassroomState:
    def __init__(self, public_origin, teacher_origins=(), limits=None, temp_parent=None):
        self.public_origin = clean_origin(public_origin)
        self.teacher_origins = {clean_origin(item) for item in teacher_origins}
        self.limits = limits or Limits()
        self.admin_token = secrets.token_urlsafe(32)
        self.lock = threading.RLock()
        self.room = None
        self.join_limits = OrderedDict()
        self.upload_slots = threading.BoundedSemaphore(self.limits.max_uploads)
        self.temp_root = Path(tempfile.mkdtemp(prefix="sound-classroom-", dir=temp_parent))

    def _room(self, room_id):
        if self.room is None or self.room["id"] != room_id:
            raise ApiError(410, "class_closed", "课堂已关闭，请向老师获取新的课堂码。")
        return self.room

    def _student(self, room, token):
        for student in room["students"].values():
            if student["token"] and secrets.compare_digest(student["token"], token):
                return student
        raise ApiError(401, "invalid_student_token", "课堂连接已失效，请重新连接。")

    def create(self, title="电子拾音器课堂"):
        if not isinstance(title, str) or len(title) > 40:
            raise ApiError(400, "invalid_title", "课堂名称最多40个字。")
        with self.lock:
            if self.room is not None:
                raise ApiError(409, "class_exists", "请先关闭当前课堂，再创建新课堂。")
            room_id = secrets.token_urlsafe(12)
            folder = self.temp_root / room_id
            folder.mkdir(mode=0o700)
            self.room = {
                "id": room_id, "code": str(secrets.randbelow(1000000)).zfill(6),
                "title": title.strip() or "电子拾音器课堂", "createdAt": time.time(),
                "students": {}, "folder": folder, "recordingBytes": 0,
                "reservedBytes": 0, "frameCount": 0,
            }
            return self._description(self.room)

    def _description(self, room):
        code = "SY1|" + self.public_origin + "|" + room["code"]
        return {
            "classId": room["id"], "code": room["code"], "title": room["title"],
            "createdAt": room["createdAt"], "connectionCode": code,
            "studentUrl": STUDENT_URL + "#classroom=" + urllib.parse.quote(code, safe=""),
            "localStudentUrl": self.public_origin + "/student.html#classroom=" + room["code"],
            "secureLocalStudent": self.public_origin.startswith("https://"),
            "limits": self.limits.public(), "uploadIntervalMs": 500,
        }

    def join(self, code, nickname, peer):
        now = time.monotonic()
        with self.lock:
            # Bounded IP buckets: a single classroom shares NAT, so successful joins
            # have no artificial per-IP throttle. Only failed guesses are limited.
            bucket = self.join_limits.setdefault(peer, deque(maxlen=20))
            self.join_limits.move_to_end(peer)
            while len(self.join_limits) > 256:
                self.join_limits.popitem(last=False)
            while bucket and now - bucket[0] > 60:
                bucket.popleft()
            if len(bucket) >= 20:
                raise ApiError(429, "join_rate_limit", "课堂码尝试过多，请稍候一分钟再试。")
            if (not isinstance(code, str) or not re.fullmatch(r"\d{6}", code)
                    or self.room is None or code != self.room["code"]):
                bucket.append(now)
                raise ApiError(404, "wrong_code", "课堂码不正确或课堂已关闭。")
            if not isinstance(nickname, str) or len(nickname.strip()) > 20:
                raise ApiError(400, "invalid_nickname", "请使用20字以内的数字或昵称。")
            if any(ord(char) < 32 for char in nickname):
                raise ApiError(400, "invalid_nickname", "昵称不能含换行或控制字符。")
            room = self.room
            if len(room["students"]) >= self.limits.max_students:
                raise ApiError(409, "class_full", "当前课堂已达到人数上限。")
            student_id, token = secrets.token_urlsafe(12), secrets.token_urlsafe(24)
            label = nickname.strip() or "同学" + str(len(room["students"]) + 1)
            room["students"][student_id] = {
                "studentId": student_id, "token": token, "nickname": label,
                "joinedAt": time.time(), "lastSeen": None, "left": False,
                "latest": None, "history": deque(maxlen=self.limits.history_per_student),
                "lastHistory": -1e9, "lastSeq": -1, "bucketTokens": 4.0,
                "bucketAt": now, "recording": None, "uploading": False,
            }
            return {
                "classId": room["id"], "code": room["code"], "studentId": student_id,
                "studentToken": token, "nickname": label, "uploadIntervalMs": 500,
                "limits": self.limits.public(),
            }

    def validate_frame(self, data):
        if not isinstance(data, dict):
            raise ApiError(400, "invalid_frame", "采集数据格式不正确。")
        seq = data.get("seq")
        if type(seq) is not int or not 0 <= seq <= 2 ** 53 - 1:
            raise ApiError(400, "invalid_frame", "采集序号格式不正确。")
        source = data.get("source", "microphone")
        if source not in {"microphone", "replay", "tone"}:
            raise ApiError(400, "invalid_frame", "声音来源格式不正确。")
        gain = data.get("inputGain", 1)
        if type(gain) not in {int, float} or gain not in INPUT_GAINS:
            raise ApiError(400, "invalid_frame", "输入增益须为1、4、8、16或32。")
        result = {
            "seq": seq, "elapsed": finite_number(data.get("elapsed", 0), "时间", 0, 86400),
            "frequency": finite_number(data.get("frequency"), "频率", 100, 3000, True),
            "rms": finite_number(data.get("rms", 0), "相对振幅", 0, 1),
            "confidence": finite_number(data.get("confidence", 0), "可信度", 0, 1),
            "inputGain": int(gain),
            "lockedFrequency": finite_number(data.get("lockedFrequency"), "锁定频率", 100, 3000, True),
            "source": source,
        }
        waveform = data.get("waveform")
        if waveform is not None:
            if not isinstance(waveform, dict):
                raise ApiError(400, "invalid_waveform", "波形格式不正确。")
            samples, sample_rate = waveform.get("samples"), waveform.get("sampleRate")
            finite_number(sample_rate, "采样率", 8000, 192000)
            if type(sample_rate) is not int:
                raise ApiError(400, "invalid_waveform", "采样率须为整数。")
            limit = min(self.limits.max_waveform_samples, math.ceil(sample_rate * 0.020))
            if not isinstance(samples, list) or not 1 <= len(samples) <= limit:
                raise ApiError(400, "invalid_waveform", "波形最多为20毫秒且不超过2048个样本。")
            clean_samples = [finite_number(x, "PCM样本", -1, 1) for x in samples]
            result["waveform"] = {"samples": clean_samples, "sampleRate": sample_rate}
        return result

    def frame(self, room_id, token, data):
        frame = self.validate_frame(data)
        now = time.monotonic()
        with self.lock:
            room = self._room(room_id)
            student = self._student(room, token)
            available = min(4.0, student["bucketTokens"] + (now - student["bucketAt"]) * 2)
            student["bucketAt"] = now
            student["bucketTokens"] = available
            if available < 1:
                raise ApiError(429, "frame_rate_limit", "数据发送过快，请每500毫秒发送一次。")
            if frame["seq"] <= student["lastSeq"]:
                raise ApiError(409, "stale_frame", "已忽略过期的数据帧。")
            student["bucketTokens"] -= 1
            frame["receivedAt"] = time.time()
            student["latest"], student["lastSeq"] = frame, frame["seq"]
            student["lastSeen"] = frame["receivedAt"]
            if now - student["lastHistory"] >= 1.0:
                student["history"].append({key: value for key, value in frame.items() if key != "waveform"})
                student["lastHistory"] = now
            room["frameCount"] += 1
            return {"ok": True, "seq": frame["seq"]}

    def leave(self, room_id, token):
        with self.lock:
            student = self._student(self._room(room_id), token)
            student["left"], student["token"] = True, ""
            return {"ok": True}

    def snapshot(self, room_id=None):
        with self.lock:
            if room_id is None and self.room is None:
                return {"classroom": None}
            room = self._room(room_id) if room_id else self.room
            result = self._description(room)
            result.update({"frameCount": room["frameCount"], "recordingBytes": room["recordingBytes"], "students": []})
            for student in room["students"].values():
                item = {key: student[key] for key in ("studentId", "nickname", "joinedAt", "lastSeen", "left", "latest")}
                item["historyCount"] = len(student["history"])
                item["recording"] = self._recording_public(student["recording"])
                result["students"].append(item)
            # Data leaves the lock only as an immutable JSON-compatible snapshot.
            result = json.loads(json.dumps(result, allow_nan=False, separators=(",", ":")))
            return {"classroom": result} if room_id is None else result

    @staticmethod
    def _recording_public(recording):
        return None if recording is None else {key: value for key, value in recording.items() if key != "path"}

    def begin_upload(self, room_id, token, size):
        if not self.upload_slots.acquire(blocking=False):
            raise ApiError(429, "uploads_busy", "正在接收其他录音，请稍后重试。")
        try:
            with self.lock:
                room = self._room(room_id)
                student = self._student(room, token)
                if student["uploading"]:
                    raise ApiError(409, "upload_in_progress", "上一段录音仍在提交。")
                if room["recordingBytes"] + room["reservedBytes"] + size > self.limits.max_recording_bytes:
                    raise ApiError(507, "recording_quota", "课堂录音空间已满，请老师导出后关闭课堂。")
                student["uploading"] = True
                room["reservedBytes"] += size
                path = room["folder"] / (secrets.token_urlsafe(15) + ".upload")
                return room, student, path
        except Exception:
            self.upload_slots.release()
            raise

    def finish_upload(self, room, student, path, size, metadata):
        with self.lock:
            self._room(room["id"])
            if student["left"]:
                raise ApiError(401, "invalid_student_token", "已退出课堂，录音未提交。")
            old = student["recording"]
            final_path = path.with_suffix(".wav")
            path.replace(final_path)
            record = dict(metadata, recordingId=final_path.stem, bytes=size, receivedAt=time.time(), path=final_path)
            student["recording"] = record
            room["recordingBytes"] += size
            if old:
                room["recordingBytes"] -= old["bytes"]
                try:
                    old["path"].unlink(missing_ok=True)
                except OSError:
                    pass
            return {"ok": True, "recording": self._recording_public(record)}

    def end_upload(self, room, student, path, size):
        with self.lock:
            room["reservedBytes"] = max(0, room["reservedBytes"] - size)
            student["uploading"] = False
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
            if self.room is not room:
                shutil.rmtree(room["folder"], ignore_errors=True)
        self.upload_slots.release()

    def recording(self, room_id, recording_id):
        with self.lock:
            room = self._room(room_id)
            for student in room["students"].values():
                record = student["recording"]
                if record and record["recordingId"] == recording_id:
                    try:
                        return record["path"].read_bytes()
                    except OSError:
                        raise ApiError(404, "recording_missing", "该录音已清理。")
            raise ApiError(404, "recording_missing", "没有找到该录音。")

    def export_csv(self, room_id):
        with self.lock:
            room = self._room(room_id)
            output = io.StringIO(newline="")
            writer = csv.writer(output)
            writer.writerow(["接收时间UTC", "学生编号", "昵称", "序号", "片段时间秒", "实时频率Hz", "锁定频率Hz", "相对RMS", "输入增益", "估计可信度", "来源"])
            for student in room["students"].values():
                for frame in student["history"]:
                    writer.writerow([
                        iso_time(frame["receivedAt"]), student["studentId"], csv_cell(student["nickname"]),
                        frame["seq"], frame["elapsed"], frame["frequency"], frame["lockedFrequency"],
                        frame["rms"], frame["inputGain"], frame["confidence"], frame["source"],
                    ])
            return ("\ufeff" + output.getvalue()).encode("utf-8")

    def close(self, room_id):
        with self.lock:
            room = self._room(room_id)
            self.room = None
            # Active uploads hold their own references only until timeout/completion.
            # Their finally block retries file cleanup, including Windows open files.
            for student in room["students"].values():
                student["token"] = ""
                student["history"].clear()
                student["latest"] = None
            shutil.rmtree(room["folder"], ignore_errors=True)
            return {"ok": True, "cleared": True}

    def dispose(self):
        with self.lock:
            if self.room:
                self.close(self.room["id"])
            self.join_limits.clear()
            shutil.rmtree(self.temp_root, ignore_errors=True)


class ClassroomHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 32

    def __init__(self, address, state, student_html=None, scheme="http", allowed_hosts=None):
        self.state = state
        self.student_html = Path(student_html) if student_html else None
        self.scheme = scheme
        self.worker_slots = threading.BoundedSemaphore(state.limits.max_workers)
        self.allowed_hosts = set(allowed_hosts or ())
        super().__init__(address, ClassroomHandler)

    def process_request(self, request, client_address):
        if not self.worker_slots.acquire(blocking=False):
            try:
                request.sendall(b"HTTP/1.1 503 Service Unavailable\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
            except OSError:
                pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self.worker_slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.worker_slots.release()

    def handle_error(self, request, client_address):
        # Do not log request bodies, class codes, authentication tokens or recordings.
        pass


class ClassroomHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "SoundClassroom/" + VERSION
    sys_version = ""

    def setup(self):
        super().setup()
        self.connection.settimeout(12)

    def log_message(self, format, *args):
        pass

    @property
    def state(self):
        return self.server.state

    def send_common(self, content_type, length):
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Connection", "close")
        origin = getattr(self, "cors_origin", None)
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.close_connection = True

    def response(self, data, status=200, content_type="application/json; charset=utf-8", attachment=None):
        body = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_common(content_type, len(body))
        if attachment:
            self.send_header("Content-Disposition", 'attachment; filename="' + attachment + '"')
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def error(self, error):
        self.response({"error": {"code": error.code, "message": error.message}}, error.status)

    def check_request(self, admin=False):
        host = self.headers.get("Host", "")
        try:
            request_origin = clean_origin(self.server.scheme + "://" + host)
        except ValueError:
            raise ApiError(400, "invalid_host", "服务地址不正确。")
        if self.server.allowed_hosts and urllib.parse.urlsplit(request_origin).netloc not in self.server.allowed_hosts:
            raise ApiError(403, "host_denied", "此主机地址未在教师服务中启用。")
        origin = self.headers.get("Origin")
        self.cors_origin = None
        if origin:
            same_origin = origin == request_origin
            allowed = same_origin or (origin in self.state.teacher_origins if admin else origin == GITHUB_ORIGIN)
            if not allowed:
                raise ApiError(403, "origin_denied", "此页面来源未获课堂服务授权。")
            self.cors_origin = origin
        if admin:
            try:
                loopback = ipaddress.ip_address(self.client_address[0]).is_loopback
            except ValueError:
                loopback = False
            if not loopback:
                raise ApiError(403, "teacher_local_only", "教师管理仅允许在运行服务的电脑上操作。")

    def token(self):
        header = self.headers.get("Authorization", "")
        if not header.startswith("Bearer ") or len(header) > 180:
            raise ApiError(401, "missing_token", "请重新打开教师启动链接或重新连接课堂。")
        return header[7:]

    def teacher_auth(self):
        self.check_request(admin=True)
        if not secrets.compare_digest(self.token(), self.state.admin_token):
            raise ApiError(403, "teacher_token_denied", "教师管理凭据不正确，请使用终端中的教师链接。")

    def content_length(self, limit):
        if self.headers.get("Transfer-Encoding"):
            raise ApiError(400, "transfer_encoding_unsupported", "请使用带确定长度的数据请求。")
        raw = self.headers.get("Content-Length", "")
        if not re.fullmatch(r"\d{1,10}", raw):
            raise ApiError(411, "length_required", "请求缺少有效的数据长度。")
        length = int(raw)
        if length > limit:
            raise ApiError(413, "body_too_large", "提交的数据超过课堂允许大小。")
        return length

    def read_json(self):
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
            raise ApiError(415, "json_required", "请使用JSON格式提交采集数据。")
        size = self.content_length(self.state.limits.max_json_bytes)
        raw = self.rfile.read(size)
        if len(raw) != size:
            raise ApiError(400, "incomplete_body", "数据没有传输完整，请重试。")
        try:
            value = json.loads(raw.decode("utf-8"), parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
            if not isinstance(value, dict):
                raise ValueError
            return value
        except (ValueError, UnicodeError, RecursionError):
            raise ApiError(400, "invalid_json", "数据格式不正确。")

    def do_OPTIONS(self):
        try:
            admin = self.path.startswith("/api/teacher/")
            self.check_request(admin=admin)
            if not self.path.startswith("/api/"):
                raise ApiError(404, "not_found", "没有这个接口。")
            method = self.headers.get("Access-Control-Request-Method", "GET")
            if method not in {"GET", "POST"}:
                raise ApiError(405, "method_not_allowed", "不支持此请求方式。")
            requested = {x.strip().lower() for x in self.headers.get("Access-Control-Request-Headers", "").split(",") if x.strip()}
            allowed = {"content-type", "authorization", "x-feature-frequency", "x-input-gain"}
            if not requested.issubset(allowed):
                raise ApiError(403, "headers_denied", "请求头不在允许范围内。")
            self.send_response(204)
            self.send_common("text/plain", 0)
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Feature-Frequency, X-Input-Gain")
            self.send_header("Access-Control-Max-Age", "600")
            self.end_headers()
        except ApiError as error:
            self.error(error)

    def do_GET(self):
        self.dispatch()

    def do_POST(self):
        self.dispatch()

    def do_HEAD(self):
        self.dispatch()

    def dispatch(self):
        try:
            path = urllib.parse.urlsplit(self.path).path
            if path.startswith("/api/teacher/"):
                self.teacher_auth()
            else:
                self.check_request()
            self.route(path)
        except ApiError as error:
            self.error(error)
        except (ConnectionError, socket.timeout, BrokenPipeError):
            self.close_connection = True
        except Exception:
            try:
                self.error(ApiError(500, "server_error", "教师服务暂时无法完成请求，请稍后重试。"))
            except OSError:
                pass

    def route(self, path):
        method = self.command
        if method in {"GET", "HEAD"} and path in {"/", "/teacher", "/teacher.html"}:
            body = Path(__file__).with_name("teacher.html").read_bytes()
            self.response(body, content_type="text/html; charset=utf-8")
            return
        if method in {"GET", "HEAD"} and path in {"/student", "/student.html"}:
            file = self.server.student_html
            if not file or not file.is_file():
                raise ApiError(404, "student_file_missing", "启动包缺少student.html，请使用包含学生网页的完整服务包。")
            self.response(file.read_bytes(), content_type="text/html; charset=utf-8")
            return
        if method == "GET" and path == "/api/health":
            self.response({"service": "sound-classroom", "version": VERSION, "secure": self.server.scheme == "https"})
            return
        if path == "/api/teacher/classes":
            if method == "POST":
                self.response(self.state.create(self.read_json().get("title", "电子拾音器课堂")), 201)
                return
            if method == "GET":
                self.response(self.state.snapshot())
                return
        if method == "POST" and path == "/api/join":
            data = self.read_json()
            self.response(self.state.join(data.get("code"), data.get("nickname", ""), self.client_address[0]), 201)
            return
        match = re.fullmatch(r"/api/classes/(" + ID_RE + r")/(frames|recordings|leave)", path)
        if match and method == "POST":
            room_id, action = match.groups()
            token = self.token()
            if action == "frames":
                self.response(self.state.frame(room_id, token, self.read_json()))
            elif action == "leave":
                # Consume a tiny optional JSON body only; clients may send {}.
                if self.headers.get("Content-Length", "0") != "0":
                    self.read_json()
                self.response(self.state.leave(room_id, token))
            else:
                self.upload_recording(room_id, token)
            return
        match = re.fullmatch(r"/api/teacher/classes/(" + ID_RE + r")(?:/(export\.csv|close|recordings/" + ID_RE + r"))?", path)
        if match:
            room_id, action = match.groups()
            if action is None and method == "GET":
                self.response(self.state.snapshot(room_id))
                return
            if action == "export.csv" and method == "GET":
                self.response(self.state.export_csv(room_id), content_type="text/csv; charset=utf-8", attachment="classroom-data.csv")
                return
            if action == "close" and method == "POST":
                self.read_json()
                self.response(self.state.close(room_id))
                return
            if action and action.startswith("recordings/") and method == "GET":
                recording_id = action.split("/")[1]
                self.response(self.state.recording(room_id, recording_id), content_type="audio/wav", attachment="recording-" + recording_id + ".wav")
                return
        raise ApiError(404, "not_found", "没有这个页面或接口。")

    def upload_recording(self, room_id, token):
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() not in {"audio/wav", "audio/wave", "audio/x-wav"}:
            raise ApiError(415, "wav_required", "请提交单声道16位PCM WAV录音。")
        size = self.content_length(self.state.limits.max_wav_bytes)
        if size < 44:
            raise ApiError(400, "invalid_wav", "录音文件不完整。")
        try:
            gain = float(self.headers.get("X-Input-Gain", "1"))
            if gain not in INPUT_GAINS:
                raise ValueError
            raw_frequency = self.headers.get("X-Feature-Frequency", "").strip()
            frequency = None if not raw_frequency else float(raw_frequency)
            finite_number(frequency, "锁定频率", 100, 3000, True)
        except (ValueError, ApiError):
            raise ApiError(400, "invalid_recording_metadata", "录音的锁定频率或输入增益不正确。")
        room, student, path = self.state.begin_upload(room_id, token, size)
        try:
            remaining = size
            with path.open("xb") as stream:
                while remaining:
                    with self.state.lock:
                        self.state._room(room_id)
                    chunk = self.rfile.read(min(65536, remaining))
                    if not chunk:
                        raise ApiError(400, "incomplete_body", "录音没有传输完整，请重试。")
                    stream.write(chunk)
                    remaining -= len(chunk)
            try:
                with wave.open(str(path), "rb") as recording:
                    sample_rate = recording.getframerate()
                    frame_count = recording.getnframes()
                    if (recording.getnchannels() != 1 or recording.getsampwidth() != 2
                            or recording.getcomptype() != "NONE" or not 8000 <= sample_rate <= 96000
                            or not 1 <= frame_count <= sample_rate * self.state.limits.max_recording_seconds):
                        raise ValueError
                    # Verify declared PCM frames really exist; never trust only WAV headers.
                    remaining_frames = frame_count
                    while remaining_frames:
                        amount = min(32768, remaining_frames)
                        if len(recording.readframes(amount)) != amount * 2:
                            raise ValueError
                        remaining_frames -= amount
                metadata = {"sampleRate": sample_rate, "frames": frame_count,
                            "duration": frame_count / sample_rate, "inputGain": int(gain),
                            "lockedFrequency": frequency}
            except (wave.Error, EOFError, ValueError, OSError):
                raise ApiError(400, "invalid_wav", "须为30秒以内、8–96kHz的单声道16位PCM WAV。")
            self.response(self.state.finish_upload(room, student, path, size, metadata), 201)
        finally:
            self.state.end_upload(room, student, path, size)


def local_hosts():
    hosts = {"localhost", "127.0.0.1"}
    try:
        hosts.add(socket.gethostname().lower())
        for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            address = item[4][0]
            if ipaddress.ip_address(address).is_private and not ipaddress.ip_address(address).is_loopback:
                hosts.add(address)
    except OSError:
        pass
    return hosts


def origin_for(scheme, host, port):
    if ":" in host:
        host = "[" + host.strip("[]") + "]"
    return clean_origin(scheme + "://" + host + ":" + str(port))


def write_startup_info(path, value):
    """Optional local automation handoff; never served by the HTTP router."""
    path = Path(path).resolve()
    descriptor, temporary = tempfile.mkstemp(prefix=".classroom-startup-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
        os.chmod(path, 0o600)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def build_parser():
    parser = argparse.ArgumentParser(description="电子拾音器课堂：本地教师服务（Python 3，无第三方依赖）")
    parser.add_argument("--bind", default="0.0.0.0", help="学生服务监听地址，默认0.0.0.0")
    parser.add_argument("--port", type=int, default=8765, help="学生服务端口，默认8765")
    parser.add_argument("--advertise-host", help="学生可访问的局域网IP；HTTPS模式填证书对应域名")
    parser.add_argument("--cert", type=Path, help="学校已配置且学生设备信任的PEM证书链")
    parser.add_argument("--key", type=Path, help="对应PEM私钥；不在此服务中安装证书信任")
    parser.add_argument("--teacher-port", type=int, help="HTTPS模式的本机HTTP管理端口，默认学生端口+1")
    parser.add_argument("--teacher-origin", action="append", default=[], help="额外允许的精确教师开发代理Origin；仍必须由loopback连接")
    parser.add_argument("--student-html", type=Path, default=Path(__file__).with_name("student.html"), help="自含学生HTML文件")
    parser.add_argument("--startup-info", type=Path, help="可选：启动信息写入仅本机0600JSON文件；含管理凭据，退出后删除")
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    if not 1 <= args.port <= 65534:
        raise SystemExit("端口须在1–65534之间。")
    if bool(args.cert) != bool(args.key):
        raise SystemExit("HTTPS须同时指定--cert和--key。")
    if args.cert and not args.advertise_host:
        raise SystemExit("HTTPS须用--advertise-host指定证书对应且学生能解析的域名或IP。")
    discovered = local_hosts()
    lan_addresses = sorted(h for h in discovered if re.fullmatch(r"\d+\.\d+\.\d+\.\d+", h) and h != "127.0.0.1")
    advertise = args.advertise_host or (lan_addresses[0] if lan_addresses else "127.0.0.1")
    discovered.add(advertise.lower())
    scheme = "https" if args.cert else "http"
    origin = origin_for(scheme, advertise, args.port)
    state = ClassroomState(origin, teacher_origins=args.teacher_origin)
    listeners = []
    background_listeners = []
    startup_written = False
    previous_terminate = None
    if threading.current_thread() is threading.main_thread():
        previous_terminate = signal.getsignal(signal.SIGTERM)
        signal.signal(signal.SIGTERM, lambda signum, frame: (_ for _ in ()).throw(KeyboardInterrupt()))
    try:
        allowed = {urllib.parse.urlsplit(origin_for(scheme, h, args.port)).netloc for h in discovered}
        server = ClassroomHTTPServer((args.bind, args.port), state, args.student_html, scheme, allowed)
        if args.cert:
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.minimum_version = ssl.TLSVersion.TLSv1_2
            context.load_cert_chain(str(args.cert), str(args.key))
            server.socket = context.wrap_socket(server.socket, server_side=True)
        listeners.append(server)
        teacher_port = args.port
        if args.cert:
            teacher_port = args.teacher_port or args.port + 1
            if not 1 <= teacher_port <= 65535 or teacher_port == args.port:
                raise ValueError("本机教师端口应为不同的有效端口。")
            admin_hosts = {"localhost:" + str(teacher_port), "127.0.0.1:" + str(teacher_port)}
            admin_server = ClassroomHTTPServer(("127.0.0.1", teacher_port), state, args.student_html, "http", admin_hosts)
            listeners.append(admin_server)
        teacher_url = "http://localhost:" + str(teacher_port) + "/teacher#admin=" + state.admin_token
        initial = state.create()
        if args.startup_info:
            write_startup_info(args.startup_info, {
                "service": "sound-classroom", "version": VERSION, "pid": os.getpid(),
                "publicOrigin": origin, "teacherUrl": teacher_url, "classroom": initial,
            })
            startup_written = True
        print("\n电子拾音器课堂 · 本地服务 " + VERSION)
        print("教师链接（仅在这台电脑打开，含管理凭据，请勿发给学生）：\n" + teacher_url)
        print("\n学生连接码：\n" + initial["connectionCode"])
        print("\n学生HTTPS网页（先预填，学生仍须主动点击连接课堂）：\n" + initial["studentUrl"])
        if args.cert:
            print("\n可信HTTPS同源学生入口：\n" + initial["localStudentUrl"])
        else:
            print("\nHTTP局域网不直接提供可录音的学生页面。使用上面的HTTPS网页和支持LNA的浏览器。")
            print("数据留在此局域网；HTTP传输未加密，请只在可信课堂网络使用。")
        if advertise == "127.0.0.1":
            print("\n未自动找到局域网IP。其他设备连接前，请用--advertise-host指定这台电脑的局域网IP。")
        if not args.student_html.is_file():
            print("\n当前包未找到student.html；GitHub学生链接仍可用，同源学生入口需要完整启动包。")
        print("\n按Ctrl+C结束服务并清理当前课堂临时数据。服务不自动打开浏览器或修改防火墙。", flush=True)
        for listener in listeners[1:]:
            threading.Thread(target=listener.serve_forever, daemon=True).start()
            background_listeners.append(listener)
        try:
            server.serve_forever(poll_interval=0.25)
        except KeyboardInterrupt:
            print("\n正在结束课堂。", flush=True)
    except (OSError, ValueError) as error:
        print("无法启动：" + str(error), file=sys.stderr)
        return 1
    finally:
        for listener in background_listeners:
            listener.shutdown()
        for listener in listeners:
            listener.server_close()
        state.dispose()
        if startup_written:
            try:
                args.startup_info.unlink(missing_ok=True)
            except OSError:
                pass
        if previous_terminate is not None:
            signal.signal(signal.SIGTERM, previous_terminate)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
