# 电子拾音器课堂 API v1

本地服务只接收显式课堂分享。它不会主动访问麦克风、远程设备或外部网络。

## 连接码与浏览器请求

跨源完整连接码：`SY1|<origin>|<六位数字>`。例如：

```text
SY1|http://192.168.1.23:8765|482913
```

`origin` 须为完整的 `http://` 或 `https://` 源地址，不包含凭据、路径、查询或 fragment。可信 HTTPS 同源学生页可只输入六位数字，地址取 `location.origin`。

分享链接使用 `#classroom=<encodeURIComponent(完整连接码)>`；同源链接可用 `#classroom=482913`。只预填，不自动连接。首次访问 LAN 应由学生主动点击触发。

GitHub HTTPS → HTTP LAN 的 `fetch` 需支持 LNA：`mode:'cors'`、`credentials:'omit'`、`targetAddressSpace:'local'`；本机回环测试用 `'loopback'`。权限名称变化和不支持的 `navigator.permissions.query()` 要捕获处理。普通同源可信 HTTPS 不依赖跨源 LNA 路线。

跨源学生请求仅允许 `Origin: https://mutiwangn.github.io`。普通 CORS 预检允许 `Content-Type, Authorization, X-Feature-Frequency, X-Input-Gain`。不使用废弃 PNA 头，不接受 `Origin: null`。错误响应在来源允许时也返回 CORS 头。

## 通用约定

- JSON 使用 UTF-8、`Content-Type: application/json`。
- 学生和教师均使用 `Authorization: Bearer <token>`，令牌不可混用。
- 不使用 Cookie；客户端不应发送 `credentials:'include'`。
- IDs 仅含 URL-safe 字母、数字、`_`、`-`。
- 成功对象为 JSON，下载端点除外。错误统一：`{"error":{"code":"machine_code","message":"中文原因"}}`。
- 主要状态码：400 参数无效，401 学生令牌失效 / 缺少令牌，403 来源或教师管理权限不允许，404 错码 / 不存在，409 课堂已存在 / 人数已满 / 过期帧，410 课堂关闭，413 请求过大，429 发送过快，507 录音容量已满。
- API 响应均 `Cache-Control: no-store`，不返回教师 token 或其他学生 token。

## 学生接口

### `POST /api/join`

```json
{"code":"482913","nickname":"12"}
```

昵称可为空（自动分配“同学1”等），最多20字；不需要真实姓名。成功 201：

```json
{
  "classId":"URL_SAFE_ID",
  "code":"482913",
  "studentId":"URL_SAFE_ID",
  "studentToken":"RANDOM_TOKEN",
  "nickname":"12",
  "uploadIntervalMs":500,
  "limits":{"maxStudents":64,"historyPerStudent":3600,"maxWaveformSamples":2048,"maxWavBytes":6291456,"maxRecordingSeconds":30,"maxRecordingBytes":134217728}
}
```

### `POST /api/classes/{classId}/frames`

使用学生 Bearer。发送已采集的最新数据，约每500ms一次。`seq` 在一次连接内严格递增。

```json
{
  "seq":1,
  "elapsed":2.35,
  "frequency":440.2,
  "lockedFrequency":440,
  "rms":0.024,
  "confidence":0.98,
  "inputGain":8,
  "source":"microphone",
  "waveform":{"samples":[0.001,0.003,-0.002],"sampleRate":48000}
}
```

`frequency` 和 `lockedFrequency` 为 `null` 或100–3000Hz。未识别时不能用0假充频率。`rms` / `confidence` 为0–1有限数，`inputGain` 为1、4、8、16或32。来源只允许 `microphone`、`replay`、`tone`。`elapsed` 是当前片段的秒数。

波形可省略。存在时，发送当前源的**真实连续尾窗**：最多 `min(ceil(sampleRate × 0.020),2048)` 个样本、原采样率8–192kHz、PCM值在[-1,1]；不要降采样、复制合成正弦或平滑替代。教师只保存最近一幅。成功200：`{"ok":true,"seq":1}`。

### `POST /api/classes/{classId}/recordings`

使用学生 Bearer；Body是原始 `audio/wav` 字节，不是 JSON / multipart / base64。可选头：

```text
X-Feature-Frequency: 440
X-Input-Gain: 8
```

`X-Feature-Frequency` 省略 / 空表示未锁定；`X-Input-Gain` 默认1。WAV须单声道、16位PCM、8–96kHz、不超过约30秒（最多0.1秒尾差）。浏览器 `fetch` 自动为 Blob / ArrayBuffer 设置 Content-Length，不要在 JS 中手写禁用的请求头。

成功201返回 `{"ok":true,"recording":{recordingId,bytes,sampleRate,frames,duration,inputGain,lockedFrequency,receivedAt}}`。每名学生仅保留最新一段；新上传通过完整校验后才替换旧段，失败时旧段保留。提交录音不等于自动上传全部本地历史。

### `POST /api/classes/{classId}/leave`

学生 Bearer，Body `{}`。成功200 `{"ok":true}`。该学生令牌立即失效，已提交数据仍保留到老师关闭课堂。重新加入生成新身份。

### `GET /api/health`

无凭据，只返回 `{service:"sound-classroom",version:"1.0",secure:boolean}`。同样应遵守显式连接后的LAN访问约定，不用于加载时自动扫描局域网。

## 教师接口

全部要求教师 Bearer，且网络连接来源必须为 loopback。服务不信任 `X-Forwarded-For`；六位码和学生 token 无管理权限。默认只接受同源；开发可用 `--teacher-origin` 添加精确代理Origin，但不能放宽peer来源。

| 请求 | 作用 |
| --- | --- |
| `GET /api/teacher/classes` | 返回 `{classroom:null}` 或 `{classroom:快照}`，用于重新打开教师页 |
| `POST /api/teacher/classes`，`{"title":"电子拾音器课堂"}` | 创建一节课堂；已有课堂时409，不覆盖旧数据 |
| `GET /api/teacher/classes/{classId}` | 直接返回课堂快照 |
| `GET /api/teacher/classes/{classId}/export.csv` | 下载UTF-8 BOM CSV；昵称有公式注入保护 |
| `GET /api/teacher/classes/{classId}/recordings/{recordingId}` | 下载WAV；教师页面用带token的fetch取Blob再回听，不把token放URL |
| `POST /api/teacher/classes/{classId}/close`，`{}` | 关闭并清空；旧客户端下一次请求返回410 |

创建响应含 `classId,code,title,createdAt,connectionCode,studentUrl,localStudentUrl,secureLocalStudent,limits,uploadIntervalMs`。快照另含 `frameCount,recordingBytes,students`。

每名学生快照含 `studentId,nickname,joinedAt,lastSeen,left,latest,historyCount,recording`。`latest` 是最后接收的帧，加教师系统秒时间戳 `receivedAt`。不会返回学生身份令牌。

## 开发启动信息

可选参数 `--startup-info /private/path/startup.json` 供本地自动化读取：

```text
{service, version, pid, publicOrigin, teacherUrl, classroom:创建响应}
```

`teacherUrl` 的 fragment 带管理 token。文件权限0600，正常退出删除，HTTP路由不会提供该文件。不要把它加入课堂启动包、仓库或网页。反向代理测试可把该URL的fragment移到受允许的代理 `/teacher`，同时确保代理从loopback连接后台。
