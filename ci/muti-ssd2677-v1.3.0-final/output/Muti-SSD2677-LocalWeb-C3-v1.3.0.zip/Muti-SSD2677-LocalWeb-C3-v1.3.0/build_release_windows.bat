@echo off
setlocal
cd /d "%~dp0"
py -m platformio run -e c3_promini_usb
if errorlevel 1 exit /b %errorlevel%
py tools\make_release.py --env c3_promini_usb
echo.
echo Build complete. See firmware\
pause
