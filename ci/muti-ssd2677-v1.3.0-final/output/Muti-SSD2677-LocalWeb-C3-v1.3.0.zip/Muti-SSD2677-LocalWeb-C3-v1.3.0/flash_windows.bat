@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  echo Usage: flash_windows.bat COM10
  exit /b 2
)
if not exist "firmware\merged-flash.bin" (
  echo firmware\merged-flash.bin not found. Run build_release_windows.bat first.
  exit /b 3
)
py -m esptool --chip esp32c3 --port %1 --baud 115200 write-flash 0x0 firmware\merged-flash.bin
