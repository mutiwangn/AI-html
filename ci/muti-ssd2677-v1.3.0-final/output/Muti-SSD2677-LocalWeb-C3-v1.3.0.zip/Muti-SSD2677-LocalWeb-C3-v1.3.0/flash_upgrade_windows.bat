@echo off
set PORT=%1
if "%PORT%"=="" set PORT=COM10
py -m esptool --chip esp32c3 --port %PORT% --baud 115200 write-flash 0x10000 firmware\firmware.bin
