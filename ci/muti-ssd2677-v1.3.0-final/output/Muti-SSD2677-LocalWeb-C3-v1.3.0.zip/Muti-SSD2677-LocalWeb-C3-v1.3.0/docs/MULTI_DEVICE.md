# Muti 多屏设备登记与控制约定

## 设备登记表

建议为每块实体屏保留一行：

| 位置 | 设备名 | Device ID | MAC | Profile | Hostname | IPv4 | 内容用途 |
|---|---|---|---|---|---|---|---|
| 办公室 | 10.2 四色 A | MUTI-... | ... | ssd2677-960x640-4c | muti-102-office.local | 192.168.2.241 | 月历 |

## 命名规则

推荐：

```text
muti-<尺寸或型号>-<位置>
```

示例：

```text
muti-102-office
muti-102-meeting
muti-426-door
muti-583-lab
muti-1248-calendar
```

## 控制前核对

自动化脚本或未来控制台应执行：

```text
目标地址 /api/status
→ 核对 device.id
→ 核对 screen.profileId
→ 核对 width / height / colors / frameBytes
→ 生成对应格式帧
→ 上传
→ 核对返回的 X-Muti-Device-ID
```

不能把一个 960×640 四色帧上传到其他分辨率或其他帧格式设备。
