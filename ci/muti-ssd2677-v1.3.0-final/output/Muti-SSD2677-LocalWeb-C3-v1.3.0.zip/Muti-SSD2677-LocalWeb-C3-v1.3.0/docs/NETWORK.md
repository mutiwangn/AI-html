# 多设备网络与身份（v1.3.0）

## 1. 设计目标

同一局域网内允许多块尺寸、分辨率和颜色能力不同的 Muti 墨水屏并存。每块设备必须能够被稳定识别，并且控制端在发送内容前能够确认目标设备能力。

## 2. 身份层级

```text
永久身份：deviceId + MAC
可读身份：deviceName + hostname
网络入口：hostname.local + IPv4
能力身份：profileId + width/height/colors/palette
```

### 永久设备 ID

由 ESP32-C3 eFuse MAC 派生：

```text
MUTI-E83DC19BAC40
```

不写入 NVS，不因清空配置而改变。

### 短编号

MAC 最后两字节，例如：

```text
AC40
```

用于外壳标签、热点名和地址卡片。

### Profile

本固件固定：

```text
ssd2677-960x640-4c
```

后续不同屏幕使用不同 Profile，控制器不应只根据 IP 猜测分辨率或颜色格式。

## 3. 地址稳定策略

### A. DHCP 地址保留（推荐）

路由器根据 MAC 固定给每块设备分配地址。优点：

- 地址冲突由路由器统一管理；
- 网关、DNS、子网变更时设备可自动适配；
- 更换路由器时只需重新建立保留规则。

### B. 设备固定 IPv4

适用于无法管理路由器的网络。固件验证：

- IP、网关、掩码和 DNS 格式；
- 掩码连续性；
- IP 与网关在同一子网；
- IP 不等于网关；
- 不使用 `.0` 或 `.255` 末地址。

固件无法知道路由器 DHCP 地址池和其他离线设备，因此仍需人工避免冲突。

## 4. 主机名

同一局域网内必须唯一。

```text
单设备临时：muti.local
多设备推荐：muti-102-office.local
             muti-102-meeting.local
             muti-426-door.local
```

全新设备默认：

```text
muti-<短编号>.local
```

已升级设备保留原主机名，避免升级后失联。

## 5. 配置热点

全新设备默认热点：

```text
Muti-102-<短编号>
```

旧设备升级保留旧热点名。AP 地址固定：

```text
192.168.4.1
```

STA 连接 20 秒失败后自动回退 AP-only。AP 与 STA 不长期并存。

## 6. mDNS 服务发现

固件发布：

```text
_http._tcp
_muti-epd._tcp
```

`_muti-epd._tcp` TXT：

```text
id=MUTI-...
profile=ssd2677-960x640-4c
fw=1.3.0
width=960
height=640
colors=4
```

该服务用于后续本地控制器发现设备。普通浏览器受平台限制，不一定能直接浏览 mDNS 服务列表。

## 7. 地址卡片

地址卡片使用固件内置 ASCII 5×7 字体直接生成 2bpp 帧，不依赖浏览器字体或服务器。显示后会成为当前 `frame.bin`，并受 180 秒全刷冷却约束。
