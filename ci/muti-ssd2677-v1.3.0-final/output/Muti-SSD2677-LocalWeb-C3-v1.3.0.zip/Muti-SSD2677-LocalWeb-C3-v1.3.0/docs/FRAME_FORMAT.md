# 960×640 四色 2bpp 帧格式

```text
宽度：960
高度：640
像素：614400
位深：2 bpp
长度：153600 B
行长度：240 B
```

每字节按高位到低位包含四个像素：

```text
bit 7..6 = pixel 0
bit 5..4 = pixel 1
bit 3..2 = pixel 2
bit 1..0 = pixel 3
```

逻辑颜色编码：

```text
0 = 黑
1 = 白
2 = 黄
3 = 红
```

浏览器打包表达式：

```javascript
packed[p >> 2] |= code << (6 - ((p & 3) * 2));
```
