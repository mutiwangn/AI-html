#include <Arduino.h>
#include <ctype.h>
#include <DNSServer.h>
#include <ESPmDNS.h>
#include <FS.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <WebServer.h>
#include <WiFi.h>
#include <esp_system.h>

#include "app_config.h"
#include "epd_ssd2677_tb.h"
#include "web_ui.h"

namespace {

using muti::config::kFrameBytes;

struct DeviceSettings {
  uint32_t version = muti::config::kSettingsVersion;
  String deviceName = "Muti 10.2 四色";
  String hostname;
  String apName;
  String staSsid;
  String staPassword;
  bool staticIpEnabled = false;
  String staticIp;
  String gateway;
  String subnet = "255.255.255.0";
  String dns1;
};

enum class NetworkState {
  Booting,
  StaConnecting,
  StaOnline,
  ApPortal,
};

enum class PendingNetworkAction {
  None,
  StartSta,
  StartAp,
};

struct UploadState {
  File file;
  size_t bytes = 0;
  uint32_t crc = 0;
  uint32_t browserCrc = 0;
  bool browserCrcPresent = false;
  bool started = false;
  bool completed = false;
  bool failed = false;
  String error;
};

struct DisplayState {
  bool pending = false;
  bool displaying = false;
  uint32_t queuedAtMs = 0;
  uint32_t lastRefreshAtMs = 0;
  uint32_t storedFrameCrc = 0;
  uint32_t displayedFrameCrc = 0;
  uint32_t lastRefreshDurationMs = 0;
  bool lastRefreshSuccess = false;
  String message = "等待操作";
};

Preferences preferences;
WebServer server(muti::config::kWebPort);
DNSServer dnsServer;
muti::EpdSsd2677Tb epd;
DeviceSettings settings;
UploadState uploadState;
DisplayState displayState;
NetworkState networkState = NetworkState::Booting;
String hostname;
String deviceId;
String shortId;
String macAddressText;
String scanCacheJson = "[]";
bool scanActive = false;
bool scanStartedFromAp = false;
bool apReady = false;
PendingNetworkAction pendingNetworkAction = PendingNetworkAction::None;
uint32_t pendingNetworkActionAtMs = 0;
bool storageMounted = false;
bool storageFormattedOnBoot = false;
String storagePartitionLabel;
String storageError;
uint32_t networkStateStartedAtMs = 0;
uint32_t restartAtMs = 0;
uint32_t lastNetworkTickMs = 0;
bool networkInfoPending = false;
uint32_t networkInfoReadyAtMs = 0;

uint32_t crc32Update(uint32_t crc, const uint8_t* data, size_t length) {
  crc = ~crc;
  for (size_t i = 0; i < length; ++i) {
    crc ^= data[i];
    for (uint8_t bit = 0; bit < 8; ++bit) {
      crc = (crc >> 1U) ^ (0xEDB88320UL & static_cast<uint32_t>(-(static_cast<int32_t>(crc & 1U))));
    }
  }
  return ~crc;
}

String hex32(uint32_t value) {
  char buffer[9];
  snprintf(buffer, sizeof(buffer), "%08lX", static_cast<unsigned long>(value));
  return String(buffer);
}

bool parseHex32(const String& text, uint32_t& value) {
  if (text.length() != 8) {
    return false;
  }
  char* end = nullptr;
  const unsigned long parsed = strtoul(text.c_str(), &end, 16);
  if (end == nullptr || *end != '\0') {
    return false;
  }
  value = static_cast<uint32_t>(parsed);
  return true;
}

String jsonEscape(const String& input) {
  String out;
  out.reserve(input.length() + 16);
  for (size_t i = 0; i < input.length(); ++i) {
    const char c = input[i];
    switch (c) {
      case '\\': out += F("\\\\"); break;
      case '"': out += F("\\\""); break;
      case '\n': out += F("\\n"); break;
      case '\r': out += F("\\r"); break;
      case '\t': out += F("\\t"); break;
      default:
        if (static_cast<uint8_t>(c) < 0x20) {
          char escaped[7];
          snprintf(escaped, sizeof(escaped), "\\u%04X", static_cast<unsigned>(static_cast<uint8_t>(c)));
          out += escaped;
        } else {
          out += c;
        }
    }
  }
  return out;
}

String boolJson(bool value) {
  return value ? F("true") : F("false");
}

void initDeviceIdentity() {
  const uint64_t efuse = ESP.getEfuseMac();
  uint8_t mac[6];
  for (uint8_t i = 0; i < 6; ++i) mac[i] = static_cast<uint8_t>((efuse >> (40U - i * 8U)) & 0xFFU);
  char macBuffer[18];
  snprintf(macBuffer, sizeof(macBuffer), "%02X:%02X:%02X:%02X:%02X:%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  macAddressText = macBuffer;
  char shortBuffer[5];
  snprintf(shortBuffer, sizeof(shortBuffer), "%02X%02X", mac[4], mac[5]);
  shortId = shortBuffer;
  char idBuffer[18];
  snprintf(idBuffer, sizeof(idBuffer), "MUTI-%02X%02X%02X%02X%02X%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  deviceId = idBuffer;
}

String defaultUniqueHostname() {
  String value = muti::config::kDefaultHostnamePrefix;
  value += shortId;
  value.toLowerCase();
  return value;
}

String defaultUniqueApName() {
  String value = muti::config::kDefaultApPrefix;
  value += shortId;
  return value;
}

String normalizeHostname(String value) {
  value.trim();
  value.toLowerCase();
  if (value.endsWith(".local")) value.remove(value.length() - 6);
  String out;
  out.reserve(32);
  bool lastDash = false;
  for (size_t i = 0; i < value.length() && out.length() < 31; ++i) {
    const char c = value[i];
    const bool allowed = (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9');
    if (allowed) { out += c; lastDash = false; }
    else if (c == '-' || c == '_' || c == ' ' || c == '.') {
      if (!out.isEmpty() && !lastDash) { out += '-'; lastDash = true; }
    }
  }
  while (out.endsWith("-")) out.remove(out.length() - 1);
  return out;
}

bool validHostname(const String& value) {
  if (value.isEmpty() || value.length() > 31 || value.startsWith("-") || value.endsWith("-")) return false;
  for (size_t i = 0; i < value.length(); ++i) {
    const char c = value[i];
    if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-')) return false;
  }
  return true;
}

bool parseIpv4(const String& text, IPAddress& result) {
  String value = text;
  value.trim();
  return !value.isEmpty() && result.fromString(value);
}

bool subnetMaskIsValid(const IPAddress& mask) {
  const uint32_t value = (static_cast<uint32_t>(mask[0]) << 24U) |
                         (static_cast<uint32_t>(mask[1]) << 16U) |
                         (static_cast<uint32_t>(mask[2]) << 8U) |
                         static_cast<uint32_t>(mask[3]);
  if (value == 0 || value == 0xFFFFFFFFUL) return false;
  const uint32_t inverse = ~value;
  return (inverse & (inverse + 1U)) == 0;
}

bool sameIpv4Subnet(const IPAddress& a, const IPAddress& b, const IPAddress& mask) {
  for (uint8_t i = 0; i < 4; ++i) {
    if ((a[i] & mask[i]) != (b[i] & mask[i])) return false;
  }
  return true;
}

bool sameIpv4Address(const IPAddress& a, const IPAddress& b) {
  for (uint8_t i = 0; i < 4; ++i) {
    if (a[i] != b[i]) return false;
  }
  return true;
}

bool validateStaticNetwork(String& error) {
  if (!settings.staticIpEnabled) return true;
  IPAddress ip, gateway, subnet, dns;
  if (!parseIpv4(settings.staticIp, ip) || !parseIpv4(settings.gateway, gateway) || !parseIpv4(settings.subnet, subnet)) {
    error = "固定IP、网关或子网掩码格式无效"; return false;
  }
  if (!subnetMaskIsValid(subnet)) { error = "子网掩码不是连续有效掩码"; return false; }
  if (!settings.dns1.isEmpty() && !parseIpv4(settings.dns1, dns)) { error = "DNS地址格式无效"; return false; }
  if (!sameIpv4Subnet(ip, gateway, subnet)) {
    error = "固定IP与网关不在同一子网"; return false;
  }
  if (sameIpv4Address(ip, gateway)) { error = "固定IP不能与网关相同"; return false; }
  const uint8_t last = ip[3];
  if (last == 0 || last == 255) { error = "固定IP不能使用网络地址或广播地址"; return false; }
  return true;
}

void saveNetworkInfoPending(bool pending) {
  networkInfoPending = pending;
  preferences.begin(muti::config::kPreferencesNamespace, false);
  preferences.putBool("netInfo", pending);
  preferences.end();
}

String networkStateName() {
  switch (networkState) {
    case NetworkState::StaConnecting: return F("sta_connecting");
    case NetworkState::StaOnline: return F("sta");
    case NetworkState::ApPortal: return F("ap");
    default: return F("booting");
  }
}

String currentIp() {
  if (networkState == NetworkState::StaOnline || networkState == NetworkState::StaConnecting) {
    return WiFi.localIP().toString();
  }
  if (networkState == NetworkState::ApPortal) {
    return WiFi.softAPIP().toString();
  }
  return F("0.0.0.0");
}

uint32_t cooldownRemainingMs() {
  if (displayState.lastRefreshAtMs == 0) {
    return 0;
  }
  const uint32_t elapsed = millis() - displayState.lastRefreshAtMs;
  return elapsed >= muti::config::kRefreshCooldownMs ? 0 : muti::config::kRefreshCooldownMs - elapsed;
}

uint32_t crcFile(const char* path, size_t* sizeOut = nullptr) {
  if (!storageMounted) {
    if (sizeOut) *sizeOut = 0;
    return 0;
  }
  File file = LittleFS.open(path, FILE_READ);
  if (!file) {
    if (sizeOut) *sizeOut = 0;
    return 0;
  }
  uint8_t buffer[1024];
  uint32_t crc = 0;
  size_t total = 0;
  while (file.available()) {
    const size_t count = file.read(buffer, sizeof(buffer));
    if (count == 0) break;
    crc = crc32Update(crc, buffer, count);
    total += count;
    yield();
  }
  file.close();
  if (sizeOut) *sizeOut = total;
  return total == 0 ? 0 : crc;
}

void saveSettings() {
  preferences.begin(muti::config::kPreferencesNamespace, false);
  preferences.putUInt("cfgVersion", settings.version);
  preferences.putString("deviceName", settings.deviceName);
  preferences.putString("hostname", settings.hostname);
  preferences.putString("apName", settings.apName);
  preferences.putString("staSsid", settings.staSsid);
  preferences.putString("staPass", settings.staPassword);
  preferences.putBool("staticEn", settings.staticIpEnabled);
  preferences.putString("staticIp", settings.staticIp);
  preferences.putString("gateway", settings.gateway);
  preferences.putString("subnet", settings.subnet);
  preferences.putString("dns1", settings.dns1);
  preferences.end();
}

void loadSettings() {
  preferences.begin(muti::config::kPreferencesNamespace, false);
  const uint32_t storedVersion = preferences.getUInt("cfgVersion", 0);
  settings.version = storedVersion;
  settings.deviceName = preferences.getString("deviceName", "Muti 10.2 四色");
  settings.hostname = preferences.getString("hostname", "");
  settings.apName = preferences.getString("apName", "");
  settings.staSsid = preferences.getString("staSsid", "");
  settings.staPassword = preferences.getString("staPass", "");
  settings.staticIpEnabled = preferences.getBool("staticEn", false);
  settings.staticIp = preferences.getString("staticIp", "");
  settings.gateway = preferences.getString("gateway", "");
  settings.subnet = preferences.getString("subnet", "255.255.255.0");
  settings.dns1 = preferences.getString("dns1", "");
  networkInfoPending = preferences.getBool("netInfo", false);
  bool migratedLegacyWifi = false;
  if (settings.staSsid.isEmpty()) {
    const String legacySsid = preferences.getString("ssid", "");
    if (!legacySsid.isEmpty()) { settings.staSsid = legacySsid; migratedLegacyWifi = true; }
  }
  if (settings.staPassword.isEmpty()) settings.staPassword = preferences.getString("staPassword", "");
  if (settings.staPassword.isEmpty()) {
    const String legacyPassword = preferences.getString("pass", "");
    if (!legacyPassword.isEmpty()) { settings.staPassword = legacyPassword; migratedLegacyWifi = true; }
  }
  if (settings.hostname.isEmpty()) {
    settings.hostname = (storedVersion > 0 || !settings.staSsid.isEmpty()) ? String(muti::config::kLegacyMdnsHostname) : defaultUniqueHostname();
  }
  settings.hostname = normalizeHostname(settings.hostname);
  if (!validHostname(settings.hostname)) settings.hostname = defaultUniqueHostname();
  if (settings.apName.isEmpty()) settings.apName = defaultUniqueApName();
  displayState.displayedFrameCrc = preferences.getUInt("shownCrc", 0);
  preferences.end();
  settings.deviceName.trim(); settings.apName.trim(); settings.staticIp.trim(); settings.gateway.trim(); settings.subnet.trim(); settings.dns1.trim();
  if (settings.deviceName.isEmpty()) settings.deviceName = "Muti 10.2 四色";
  if (settings.apName.isEmpty()) settings.apName = defaultUniqueApName();
  if (settings.apName.length() > 31) settings.apName.remove(31);
  if (settings.subnet.isEmpty()) settings.subnet = "255.255.255.0";
  String staticError;
  if (!validateStaticNetwork(staticError)) {
    Serial.printf("[NVS] disabling invalid static network config: %s\n", staticError.c_str());
    settings.staticIpEnabled = false;
  }
  settings.version = muti::config::kSettingsVersion;
  saveSettings();
  if (migratedLegacyWifi) Serial.printf("[NVS] migrated legacy Wi-Fi keys for SSID=%s\n", settings.staSsid.c_str());
  Serial.printf("[IDENTITY] id=%s short=%s mac=%s name=%s host=%s.local ap=%s\n", deviceId.c_str(), shortId.c_str(), macAddressText.c_str(), settings.deviceName.c_str(), settings.hostname.c_str(), settings.apName.c_str());
}

void saveDisplayedCrc(uint32_t crc) {
  preferences.begin(muti::config::kPreferencesNamespace, false);
  preferences.putUInt("shownCrc", crc);
  preferences.end();
}

String makeHostname() {
  return settings.hostname;
}

void stopMdns() {
  MDNS.end();
}

void startMdns() {
  stopMdns();
  if (MDNS.begin(hostname.c_str())) {
    MDNS.setInstanceName(settings.deviceName);
    MDNS.addService("http", "tcp", muti::config::kWebPort);
    MDNS.addService("muti-epd", "tcp", muti::config::kWebPort);
    MDNS.addServiceTxt("muti-epd", "tcp", "id", deviceId);
    MDNS.addServiceTxt("muti-epd", "tcp", "profile", muti::config::kProfileId);
    MDNS.addServiceTxt("muti-epd", "tcp", "fw", muti::config::kFirmwareVersion);
    MDNS.addServiceTxt("muti-epd", "tcp", "width", String(muti::config::kDisplayWidth));
    MDNS.addServiceTxt("muti-epd", "tcp", "height", String(muti::config::kDisplayHeight));
    MDNS.addServiceTxt("muti-epd", "tcp", "colors", "4");
    Serial.printf("[NET] mDNS: http://%s.local/ id=%s profile=%s\n", hostname.c_str(), deviceId.c_str(), muti::config::kProfileId);
  } else {
    Serial.println(F("[NET] mDNS start failed; use the numeric IP address"));
  }
}

String pendingNetworkActionName() {
  switch (pendingNetworkAction) {
    case PendingNetworkAction::StartSta: return F("start_sta");
    case PendingNetworkAction::StartAp: return F("start_ap");
    default: return F("none");
  }
}

void scheduleNetworkAction(PendingNetworkAction action, uint32_t delayMs) {
  pendingNetworkAction = action;
  pendingNetworkActionAtMs = millis() + delayMs;
}

void startApPortal() {
  Serial.printf("[NET] starting AP-only: %s\n", settings.apName.c_str());
  stopMdns();
  dnsServer.stop();
  pendingNetworkAction = PendingNetworkAction::None;
  apReady = false;
  WiFi.softAPdisconnect(true);
  WiFi.disconnect(true, false);
  WiFi.mode(WIFI_OFF);
  delay(120);

  const IPAddress apIp(192, 168, 4, 1);
  const IPAddress subnet(255, 255, 255, 0);
  bool ok = false;
  for (uint8_t attempt = 1; attempt <= 3 && !ok; ++attempt) {
    WiFi.mode(WIFI_AP);
    WiFi.setSleep(false);
    const bool configured = WiFi.softAPConfig(apIp, apIp, subnet);
    ok = configured && WiFi.softAP(settings.apName.c_str(), nullptr, muti::config::kApChannel, false,
                                   muti::config::kApMaxClients);
    Serial.printf("[NET] AP attempt %u configured=%s started=%s\n", attempt,
                  configured ? "yes" : "no", ok ? "yes" : "no");
    if (!ok) {
      WiFi.softAPdisconnect(true);
      WiFi.mode(WIFI_OFF);
      delay(220);
    }
  }

  networkState = NetworkState::ApPortal;
  networkStateStartedAtMs = millis();
  apReady = ok;
  if (ok) {
    dnsServer.start(53, "*", WiFi.softAPIP());
    startMdns();
    Serial.printf("[NET] AP ready: %s IP=%s mDNS=http://%s.local/ id=%s\n", settings.apName.c_str(),
                  WiFi.softAPIP().toString().c_str(), hostname.c_str(), deviceId.c_str());
    if (networkInfoPending) networkInfoReadyAtMs = millis() + muti::config::kNetworkInfoDelayMs;
  } else if (!settings.staSsid.isEmpty()) {
    Serial.println(F("[NET][ERROR] AP start failed; retrying saved STA"));
    scheduleNetworkAction(PendingNetworkAction::StartSta, 300);
  } else {
    Serial.println(F("[NET][ERROR] AP start failed; restart device to retry"));
  }
}

void startStaConnection() {
  if (settings.staSsid.isEmpty()) {
    startApPortal();
    return;
  }
  Serial.printf("[NET] starting STA-only: %s\n", settings.staSsid.c_str());
  pendingNetworkAction = PendingNetworkAction::None;
  apReady = false;
  stopMdns();
  dnsServer.stop();
  WiFi.softAPdisconnect(true);
  WiFi.disconnect(true, false);
  delay(50);
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);
  WiFi.persistent(false);
  WiFi.setHostname(hostname.c_str());
  bool ipConfigOk = true;
  if (settings.staticIpEnabled) {
    IPAddress ip, gateway, subnet, dns;
    ip.fromString(settings.staticIp);
    gateway.fromString(settings.gateway);
    subnet.fromString(settings.subnet);
    if (!settings.dns1.isEmpty()) dns.fromString(settings.dns1);
    else dns = gateway;
    ipConfigOk = WiFi.config(ip, gateway, subnet, dns);
    Serial.printf("[NET] static IPv4 %s gateway=%s mask=%s dns=%s configured=%s\n", settings.staticIp.c_str(), settings.gateway.c_str(), settings.subnet.c_str(), dns.toString().c_str(), ipConfigOk ? "yes" : "no");
  } else {
    ipConfigOk = WiFi.config(IPAddress(), IPAddress(), IPAddress());
    Serial.printf("[NET] DHCP configured=%s\n", ipConfigOk ? "yes" : "no");
  }
  if (!ipConfigOk) {
    Serial.println(F("[NET][ERROR] IP configuration failed; falling back to AP-only"));
    startApPortal();
    return;
  }
  WiFi.begin(settings.staSsid.c_str(), settings.staPassword.c_str());
  networkState = NetworkState::StaConnecting;
  networkStateStartedAtMs = millis();
}

void manageNetwork() {
  if (millis() - lastNetworkTickMs < muti::config::kNetworkTickMs) return;
  lastNetworkTickMs = millis();

  if (pendingNetworkAction != PendingNetworkAction::None &&
      static_cast<int32_t>(millis() - pendingNetworkActionAtMs) >= 0 && !displayState.displaying) {
    const PendingNetworkAction action = pendingNetworkAction;
    pendingNetworkAction = PendingNetworkAction::None;
    if (action == PendingNetworkAction::StartSta) startStaConnection();
    else if (action == PendingNetworkAction::StartAp) startApPortal();
    return;
  }

  if (networkState == NetworkState::ApPortal && apReady) {
    dnsServer.processNextRequest();
  }

  if (networkState == NetworkState::StaConnecting) {
    if (WiFi.status() == WL_CONNECTED) {
      networkState = NetworkState::StaOnline;
      networkStateStartedAtMs = millis();
      startMdns();
      Serial.printf("[NET] STA connected: %s IP=%s RSSI=%d host=%s.local id=%s\n", settings.staSsid.c_str(), WiFi.localIP().toString().c_str(), WiFi.RSSI(), hostname.c_str(), deviceId.c_str());
      if (networkInfoPending) networkInfoReadyAtMs = millis() + muti::config::kNetworkInfoDelayMs;
    } else if (millis() - networkStateStartedAtMs >= muti::config::kStaConnectTimeoutMs) {
      Serial.printf("[NET] STA timeout (%d); falling back to AP-only\n", static_cast<int>(WiFi.status()));
      startApPortal();
    }
  } else if (networkState == NetworkState::StaOnline && WiFi.status() != WL_CONNECTED) {
    Serial.println(F("[NET] STA disconnected; retrying in STA-only mode"));
    WiFi.reconnect();
    networkState = NetworkState::StaConnecting;
    networkStateStartedAtMs = millis() -
        (muti::config::kStaConnectTimeoutMs > muti::config::kStaReconnectWindowMs
             ? muti::config::kStaConnectTimeoutMs - muti::config::kStaReconnectWindowMs
             : 0);
  }

  if (scanActive) {
    const int result = WiFi.scanComplete();
    if (result >= 0) {
      String json = "[";
      for (int i = 0; i < result; ++i) {
        if (i) json += ',';
        json += F("{\"ssid\":\"");
        json += jsonEscape(WiFi.SSID(i));
        json += F("\",\"rssi\":");
        json += WiFi.RSSI(i);
        json += F(",\"channel\":");
        json += WiFi.channel(i);
        json += F(",\"secure\":");
        json += boolJson(WiFi.encryptionType(i) != WIFI_AUTH_OPEN);
        json += '}';
      }
      json += ']';
      scanCacheJson = json;
      WiFi.scanDelete();
      scanActive = false;
      if (scanStartedFromAp) {
        WiFi.mode(WIFI_AP);
        scanStartedFromAp = false;
      }
      Serial.printf("[NET] scan complete: %d networks\n", result);
    } else if (result == WIFI_SCAN_FAILED) {
      scanActive = false;
      scanCacheJson = "[]";
      if (scanStartedFromAp) {
        WiFi.mode(WIFI_AP);
        scanStartedFromAp = false;
      }
      Serial.println(F("[NET] scan failed"));
    }
  }
}

bool startWifiScan() {
  if (scanActive || displayState.displaying) return false;
  WiFi.scanDelete();
  scanStartedFromAp = networkState == NetworkState::ApPortal;
  if (scanStartedFromAp) {
    WiFi.mode(WIFI_AP_STA);  // temporary only; AP remains available during scan
  }
  const int rc = WiFi.scanNetworks(true, true, false, 250);
  scanActive = rc == WIFI_SCAN_RUNNING;
  if (!scanActive && scanStartedFromAp) {
    WiFi.mode(WIFI_AP);
    scanStartedFromAp = false;
  }
  return scanActive;
}

bool atomicInstallTempFrame() {
  if (!storageMounted) return false;
  LittleFS.remove(muti::config::kFrameBackupPath);
  const bool hadCurrent = LittleFS.exists(muti::config::kFramePath);
  if (hadCurrent && !LittleFS.rename(muti::config::kFramePath, muti::config::kFrameBackupPath)) {
    return false;
  }
  if (!LittleFS.rename(muti::config::kUploadTempPath, muti::config::kFramePath)) {
    if (hadCurrent) LittleFS.rename(muti::config::kFrameBackupPath, muti::config::kFramePath);
    return false;
  }
  LittleFS.remove(muti::config::kFrameBackupPath);
  return true;
}

void resetUploadState() {
  if (uploadState.file) uploadState.file.close();
  uploadState = UploadState{};
}

void handleUploadChunk() {
  HTTPUpload& upload = server.upload();
  switch (upload.status) {
    case UPLOAD_FILE_START: {
      resetUploadState();
      uploadState.started = true;
      uint32_t browserCrc = 0;
      uploadState.browserCrcPresent = parseHex32(server.header("X-Frame-CRC32"), browserCrc);
      uploadState.browserCrc = browserCrc;
      if (!storageMounted) {
        uploadState.failed = true;
        uploadState.error = storageError.isEmpty() ? "LittleFS未挂载" : storageError;
        break;
      }
      LittleFS.remove(muti::config::kUploadTempPath);
      uploadState.file = LittleFS.open(muti::config::kUploadTempPath, FILE_WRITE);
      if (!uploadState.file) {
        uploadState.failed = true;
        uploadState.error = String("无法创建 /upload.tmp；LittleFS mounted=") + (storageMounted ? "true" : "false") +
                            " label=" + storagePartitionLabel +
                            " total=" + LittleFS.totalBytes() + " used=" + LittleFS.usedBytes();
      }
      break;
    }
    case UPLOAD_FILE_WRITE:
      if (!uploadState.failed) {
        if (uploadState.bytes + upload.currentSize > kFrameBytes) {
          uploadState.failed = true;
          uploadState.error = "上传长度超过153600字节";
        } else {
          const size_t written = uploadState.file.write(upload.buf, upload.currentSize);
          if (written != upload.currentSize) {
            uploadState.failed = true;
            uploadState.error = "LittleFS写入失败";
          } else {
            uploadState.crc = crc32Update(uploadState.crc, upload.buf, upload.currentSize);
            uploadState.bytes += upload.currentSize;
          }
        }
      }
      break;
    case UPLOAD_FILE_END:
      if (uploadState.file) uploadState.file.close();
      uploadState.completed = true;
      break;
    case UPLOAD_FILE_ABORTED:
      if (uploadState.file) uploadState.file.close();
      uploadState.failed = true;
      uploadState.completed = true;
      uploadState.error = "上传被中止";
      if (storageMounted) LittleFS.remove(muti::config::kUploadTempPath);
      break;
    default:
      break;
  }
}

void sendJson(int statusCode, const String& body) {
  server.sendHeader("Cache-Control", "no-store");
  server.sendHeader("X-Muti-Device-ID", deviceId);
  server.send(statusCode, "application/json; charset=utf-8", body);
}

void handleUploadComplete() {
  if (!uploadState.started || !uploadState.completed) {
    sendJson(400, F("{\"ok\":false,\"error\":\"上传状态不完整\"}"));
    resetUploadState();
    return;
  }
  if (uploadState.failed || uploadState.bytes != kFrameBytes) {
    if (storageMounted) LittleFS.remove(muti::config::kUploadTempPath);
    String error = uploadState.failed ? uploadState.error : String("帧长度为") + uploadState.bytes + "，必须为153600";
    sendJson(400, String("{\"ok\":false,\"error\":\"") + jsonEscape(error) + "\"}");
    resetUploadState();
    return;
  }
  if (uploadState.browserCrcPresent && uploadState.browserCrc != uploadState.crc) {
    if (storageMounted) LittleFS.remove(muti::config::kUploadTempPath);
    String body = String("{\"ok\":false,\"error\":\"浏览器CRC与设备CRC不一致\",\"browserCrc32\":\"") +
                  hex32(uploadState.browserCrc) + "\",\"deviceCrc32\":\"" + hex32(uploadState.crc) + "\"}";
    sendJson(422, body);
    resetUploadState();
    return;
  }

  const uint32_t newCrc = uploadState.crc;
  if (!atomicInstallTempFrame()) {
    if (storageMounted) LittleFS.remove(muti::config::kUploadTempPath);
    sendJson(500, F("{\"ok\":false,\"error\":\"无法原子替换frame.bin\"}"));
    resetUploadState();
    return;
  }

  displayState.storedFrameCrc = newCrc;
  const bool sameAsDisplayed = displayState.displayedFrameCrc != 0 && newCrc == displayState.displayedFrameCrc;
  if (!sameAsDisplayed) {
    displayState.pending = true;
    displayState.queuedAtMs = millis();
    displayState.message = cooldownRemainingMs() ? "画面已保存，等待冷却后刷新" : "画面已保存，等待刷新";
  } else {
    displayState.pending = false;
    displayState.message = "相同画面，已跳过刷新";
  }

  String body;
  body.reserve(220);
  body += F("{\"ok\":true,\"bytes\":153600,\"crc32\":\"");
  body += hex32(newCrc);
  body += F("\",\"queued\":");
  body += boolJson(!sameAsDisplayed);
  body += F(",\"sameFrame\":");
  body += boolJson(sameAsDisplayed);
  body += F(",\"cooldownRemainingMs\":");
  body += cooldownRemainingMs();
  body += '}';
  sendJson(200, body);
  resetUploadState();
}

uint8_t packedByte(uint8_t a, uint8_t b, uint8_t c, uint8_t d) {
  return static_cast<uint8_t>((a << 6U) | (b << 4U) | (c << 2U) | d);
}

void setPackedPixel(uint8_t* row, uint16_t x, uint8_t code) {
  const uint16_t byteIndex = x >> 2U;
  const uint8_t shift = 6U - static_cast<uint8_t>((x & 3U) * 2U);
  row[byteIndex] = static_cast<uint8_t>((row[byteIndex] & ~(0x03U << shift)) | ((code & 0x03U) << shift));
}

enum class PatternKind { Raw, Palette, Gray16, White, NetworkInfo };

const uint8_t* glyph5x7(char input) {
  static const uint8_t blank[5] = {0, 0, 0, 0, 0};
  static const uint8_t dash[5] = {0x08, 0x08, 0x08, 0x08, 0x08};
  static const uint8_t dot[5] = {0x00, 0x60, 0x60, 0x00, 0x00};
  static const uint8_t colon[5] = {0x00, 0x36, 0x36, 0x00, 0x00};
  static const uint8_t slash[5] = {0x20, 0x10, 0x08, 0x04, 0x02};
  static const uint8_t digits[10][5] = {
      {0x3E,0x51,0x49,0x45,0x3E},{0x00,0x42,0x7F,0x40,0x00},{0x42,0x61,0x51,0x49,0x46},{0x21,0x41,0x45,0x4B,0x31},{0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},{0x3C,0x4A,0x49,0x49,0x30},{0x01,0x71,0x09,0x05,0x03},{0x36,0x49,0x49,0x49,0x36},{0x06,0x49,0x49,0x29,0x1E}};
  static const uint8_t letters[26][5] = {
      {0x7E,0x11,0x11,0x11,0x7E},{0x7F,0x49,0x49,0x49,0x36},{0x3E,0x41,0x41,0x41,0x22},{0x7F,0x41,0x41,0x22,0x1C},{0x7F,0x49,0x49,0x49,0x41},{0x7F,0x09,0x09,0x09,0x01},{0x3E,0x41,0x49,0x49,0x7A},{0x7F,0x08,0x08,0x08,0x7F},{0x00,0x41,0x7F,0x41,0x00},{0x20,0x40,0x41,0x3F,0x01},{0x7F,0x08,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},{0x7F,0x02,0x0C,0x02,0x7F},{0x7F,0x04,0x08,0x10,0x7F},{0x3E,0x41,0x41,0x41,0x3E},{0x7F,0x09,0x09,0x09,0x06},{0x3E,0x41,0x51,0x21,0x5E},{0x7F,0x09,0x19,0x29,0x46},{0x46,0x49,0x49,0x49,0x31},{0x01,0x01,0x7F,0x01,0x01},{0x3F,0x40,0x40,0x40,0x3F},{0x1F,0x20,0x40,0x20,0x1F},{0x3F,0x40,0x38,0x40,0x3F},{0x63,0x14,0x08,0x14,0x63},{0x07,0x08,0x70,0x08,0x07},{0x61,0x51,0x49,0x45,0x43}};
  char c = input;
  if (c >= 'a' && c <= 'z') c = static_cast<char>(c - 'a' + 'A');
  if (c >= '0' && c <= '9') return digits[c - '0'];
  if (c >= 'A' && c <= 'Z') return letters[c - 'A'];
  if (c == '-') return dash;
  if (c == '.') return dot;
  if (c == ':') return colon;
  if (c == '/') return slash;
  return blank;
}

void fillRowSpan(uint8_t* row, int x0, int x1, uint8_t code) {
  if (x1 < 0 || x0 >= muti::config::kDisplayWidth || x0 > x1) return;
  if (x0 < 0) x0 = 0;
  if (x1 >= muti::config::kDisplayWidth) x1 = muti::config::kDisplayWidth - 1;
  for (int x = x0; x <= x1; ++x) setPackedPixel(row, static_cast<uint16_t>(x), code);
}

void drawTextOnRow(uint8_t* row, uint16_t currentY, int x0, int y0, uint8_t scale, uint8_t code, String text) {
  text.toUpperCase();
  const int localY = static_cast<int>(currentY) - y0;
  if (localY < 0 || localY >= 7 * scale) return;
  const uint8_t glyphY = static_cast<uint8_t>(localY / scale);
  int cursor = x0;
  for (size_t i = 0; i < text.length(); ++i) {
    const uint8_t* glyph = glyph5x7(text[i]);
    for (uint8_t gx = 0; gx < 5; ++gx) {
      if ((glyph[gx] & (1U << glyphY)) == 0) continue;
      fillRowSpan(row, cursor + gx * scale, cursor + (gx + 1) * scale - 1, code);
    }
    cursor += 6 * scale;
    if (cursor >= muti::config::kDisplayWidth) break;
  }
}

String networkInfoLine(const char* label, const String& value) {
  String line = label; line += value; return line;
}

bool generatePattern(PatternKind kind, uint32_t& crcOut) {
  if (!storageMounted) return false;
  LittleFS.remove(muti::config::kUploadTempPath);
  File file = LittleFS.open(muti::config::kUploadTempPath, FILE_WRITE);
  if (!file) return false;

  static constexpr uint8_t bayer4[4][4] = {
      {0, 8, 2, 10}, {12, 4, 14, 6}, {3, 11, 1, 9}, {15, 7, 13, 5}};
  uint8_t row[muti::config::kRowBytes];
  uint32_t crc = 0;
  const String infoHost = settings.hostname + ".local";
  const String infoIp = currentIp();
  const String infoProfile = String(muti::config::kDisplayWidth) + "X" + muti::config::kDisplayHeight + " 4C";

  for (uint16_t y = 0; y < muti::config::kDisplayHeight; ++y) {
    memset(row, 0x55, sizeof(row));  // white code 1
    for (uint16_t x = 0; x < muti::config::kDisplayWidth; ++x) {
      uint8_t code = muti::config::kLogicalWhite;
      if (kind == PatternKind::White) {
        code = muti::config::kLogicalWhite;
      } else if (kind == PatternKind::Raw) {
        code = static_cast<uint8_t>((x / (muti::config::kDisplayWidth / 4)) > 3 ? 3 : (x / (muti::config::kDisplayWidth / 4)));
      } else if (kind == PatternKind::Palette) {
        const bool top = y < muti::config::kDisplayHeight / 2;
        const bool left = x < muti::config::kDisplayWidth / 2;
        code = top ? (left ? 0 : 1) : (left ? 2 : 3);
        const uint16_t border = 12;
        if (x < border || y < border || x >= muti::config::kDisplayWidth - border ||
            y >= muti::config::kDisplayHeight - border) {
          code = muti::config::kLogicalWhite;
        }
      } else if (kind == PatternKind::NetworkInfo) {
        code = muti::config::kLogicalWhite;
      } else if (kind == PatternKind::Gray16) {
        const uint8_t rawLevel = static_cast<uint8_t>(x / (muti::config::kDisplayWidth / 16));
        const uint8_t level = rawLevel > 15 ? 15 : rawLevel;
        const uint8_t blackCells = static_cast<uint8_t>((static_cast<uint16_t>(level) * 16U + 7U) / 15U);
        code = bayer4[y & 3U][x & 3U] < blackCells ? muti::config::kLogicalBlack
                                                   : muti::config::kLogicalWhite;
      }
      setPackedPixel(row, x, code);
    }
    if (kind == PatternKind::NetworkInfo) {
      if (y < 100) fillRowSpan(row, 0, muti::config::kDisplayWidth - 1, muti::config::kLogicalRed);
      if (y >= 100 && y < 112) fillRowSpan(row, 0, muti::config::kDisplayWidth - 1, muti::config::kLogicalYellow);
      if (y < 8 || y >= muti::config::kDisplayHeight - 8) fillRowSpan(row, 0, muti::config::kDisplayWidth - 1, muti::config::kLogicalBlack);
      else { fillRowSpan(row, 0, 7, muti::config::kLogicalBlack); fillRowSpan(row, muti::config::kDisplayWidth - 8, muti::config::kDisplayWidth - 1, muti::config::kLogicalBlack); }
      drawTextOnRow(row, y, 38, 20, 8, muti::config::kLogicalWhite, "MUTI DEVICE");
      drawTextOnRow(row, y, 48, 138, 5, muti::config::kLogicalBlack, networkInfoLine("NAME: ", settings.hostname));
      drawTextOnRow(row, y, 48, 198, 5, muti::config::kLogicalRed, networkInfoLine("ID: ", shortId));
      drawTextOnRow(row, y, 48, 258, 7, muti::config::kLogicalBlack, networkInfoLine("IP: ", infoIp));
      drawTextOnRow(row, y, 48, 340, 4, muti::config::kLogicalBlack, networkInfoLine("HOST: ", infoHost));
      drawTextOnRow(row, y, 48, 396, 4, muti::config::kLogicalBlack, networkInfoLine("PROFILE: ", infoProfile));
      drawTextOnRow(row, y, 48, 452, 3, muti::config::kLogicalBlack, networkInfoLine("MAC: ", macAddressText));
      drawTextOnRow(row, y, 48, 512, 4, muti::config::kLogicalRed, networkState == NetworkState::ApPortal ? "OPEN 192.168.4.1" : "OPEN IN BROWSER");
      drawTextOnRow(row, y, 48, 570, 3, muti::config::kLogicalBlack, networkInfoLine("DEVICE: ", deviceId));
    }
    if (file.write(row, sizeof(row)) != sizeof(row)) {
      file.close();
      LittleFS.remove(muti::config::kUploadTempPath);
      return false;
    }
    crc = crc32Update(crc, row, sizeof(row));
    yield();
  }
  file.close();
  if (!atomicInstallTempFrame()) return false;
  crcOut = crc;
  displayState.storedFrameCrc = crc;
  displayState.pending = displayState.displayedFrameCrc != crc;
  displayState.queuedAtMs = millis();
  displayState.message = displayState.pending ? "测试图已生成，等待刷新" : "测试图与已显示画面相同";
  return true;
}

void processPendingNetworkInfo() {
  if (!networkInfoPending || networkInfoReadyAtMs == 0 || static_cast<int32_t>(millis() - networkInfoReadyAtMs) < 0) return;
  if (displayState.displaying || displayState.pending || epd.faultLatched() || !storageMounted) return;
  if (!(networkState == NetworkState::StaOnline || (networkState == NetworkState::ApPortal && apReady))) return;
  uint32_t crc = 0;
  if (generatePattern(PatternKind::NetworkInfo, crc)) {
    saveNetworkInfoPending(false);
    networkInfoReadyAtMs = 0;
    displayState.message = displayState.pending ? "设备信息卡已生成，等待刷新" : "设备信息卡与已显示画面相同";
    Serial.printf("[DISPLAY] network info card queued crc=%s ip=%s host=%s.local\n", hex32(crc).c_str(), currentIp().c_str(), hostname.c_str());
  }
}

void processPendingDisplay() {
  if (!displayState.pending || displayState.displaying || epd.faultLatched()) return;
  if (!storageMounted) {
    displayState.pending = false;
    displayState.message = storageError.isEmpty() ? "LittleFS未挂载，无法刷新" : storageError;
    return;
  }
  if (millis() - displayState.queuedAtMs < muti::config::kRefreshQueueDelayMs) return;
  if (cooldownRemainingMs() != 0) return;
  if (!LittleFS.exists(muti::config::kFramePath)) {
    displayState.pending = false;
    displayState.message = "frame.bin不存在";
    return;
  }

  displayState.displaying = true;
  displayState.message = "屏幕刷新中；网页请求会暂时等待";
  Serial.printf("[DISPLAY] starting frame crc=%s\n", hex32(displayState.storedFrameCrc).c_str());
  const bool ok = epd.displayFile(LittleFS, muti::config::kFramePath, displayState.storedFrameCrc);
  displayState.displaying = false;
  displayState.lastRefreshSuccess = ok;
  displayState.lastRefreshDurationMs = epd.report().totalMs;
  if (ok) {
    displayState.pending = false;
    displayState.lastRefreshAtMs = millis();
    displayState.displayedFrameCrc = epd.report().frameCrc32;
    saveDisplayedCrc(displayState.displayedFrameCrc);
    displayState.message = "刷新完成";
  } else {
    displayState.pending = false;
    displayState.message = epd.report().needsPhysicalPowerCycle
                               ? "刷新故障已锁定：同时断开USB和驱动板供电至少30秒"
                               : String("刷新失败：") + epd.report().error;
  }
}

String statusJson() {
  size_t frameSize = 0;
  const bool frameExists = storageMounted && LittleFS.exists(muti::config::kFramePath);
  if (frameExists) {
    File f = LittleFS.open(muti::config::kFramePath, FILE_READ);
    if (f) {
      frameSize = f.size();
      f.close();
    }
  }
  const muti::EpdTbRefreshReport& r = epd.report();
  String json;
  json.reserve(2800);
  json += F("{\"firmware\":{\"name\":\"");
  json += muti::config::kFirmwareName;
  json += F("\",\"version\":\"");
  json += muti::config::kFirmwareVersion;
  json += F("\",\"build\":\"");
  json += jsonEscape(muti::config::kBuildDate);
  json += F("\"},\"device\":{\"name\":\"");
  json += jsonEscape(settings.deviceName);
  json += F("\",\"id\":\"");
  json += deviceId;
  json += F("\",\"shortId\":\"");
  json += shortId;
  json += F("\",\"mac\":\"");
  json += macAddressText;
  json += F("\",\"profileId\":\"");
  json += muti::config::kProfileId;
  json += F("\",\"uptimeMs\":");
  json += millis();
  json += F("},\"network\":{\"mode\":\"");
  json += networkStateName();
  json += F("\",\"ssid\":\"");
  json += jsonEscape(networkState == NetworkState::ApPortal ? settings.apName : settings.staSsid);
  json += F("\",\"ip\":\"");
  json += currentIp();
  json += F("\",\"hostname\":\"");
  json += hostname;
  json += F("\",\"rssi\":");
  json += networkState == NetworkState::StaOnline ? WiFi.RSSI() : 0;
  json += F(",\"savedSsid\":\"");
  json += jsonEscape(settings.staSsid);
  json += F("\",\"ipMode\":\"");
  json += settings.staticIpEnabled ? F("static") : F("dhcp");
  json += F("\",\"configuredIp\":\"");
  json += jsonEscape(settings.staticIp);
  json += F("\",\"configuredGateway\":\"");
  json += jsonEscape(settings.gateway);
  json += F("\",\"configuredSubnet\":\"");
  json += jsonEscape(settings.subnet);
  json += F("\",\"configuredDns1\":\"");
  json += jsonEscape(settings.dns1);
  json += F("\",\"gateway\":\"");
  json += networkState == NetworkState::StaOnline ? WiFi.gatewayIP().toString() : String("");
  json += F("\",\"subnet\":\"");
  json += networkState == NetworkState::StaOnline ? WiFi.subnetMask().toString() : String("");
  json += F("\",\"dns1\":\"");
  json += networkState == NetworkState::StaOnline ? WiFi.dnsIP(0).toString() : String("");
  json += F("\",\"networkInfoPending\":");
  json += boolJson(networkInfoPending);
  json += F(",\"apReady\":");
  json += boolJson(apReady);
  json += F(",\"apClients\":");
  json += networkState == NetworkState::ApPortal && apReady ? WiFi.softAPgetStationNum() : 0;
  json += F(",\"pendingAction\":\"");
  json += pendingNetworkActionName();
  json += F("\",\"scanActive\":");
  json += boolJson(scanActive);
  json += F("},\"display\":{\"state\":\"");
  if (displayState.displaying) json += F("refreshing");
  else if (epd.faultLatched()) json += F("fault");
  else if (displayState.pending) json += F("queued");
  else json += F("idle");
  json += F("\",\"message\":\"");
  json += jsonEscape(displayState.message);
  json += F("\",\"busyPin\":");
  json += digitalRead(muti::config::kPinBusy);
  json += F(",\"fault\":");
  json += boolJson(epd.faultLatched());
  json += F(",\"pending\":");
  json += boolJson(displayState.pending);
  json += F(",\"cooldownRemainingMs\":");
  json += cooldownRemainingMs();
  json += F(",\"lastRefreshMs\":");
  json += displayState.lastRefreshDurationMs;
  json += F(",\"lastRefreshSuccess\":");
  json += boolJson(displayState.lastRefreshSuccess);
  json += F(",\"driverStage\":\"");
  json += jsonEscape(r.stage);
  json += F("\",\"driverError\":\"");
  json += jsonEscape(r.error);
  json += F("\",\"psr\":\"9F A9\",\"vcom\":\"9C\",\"vbd\":\"37\"},\"frame\":{\"exists\":");
  json += boolJson(frameExists);
  json += F(",\"bytes\":");
  json += frameSize;
  json += F(",\"storedCrc32\":\"");
  json += hex32(displayState.storedFrameCrc);
  json += F("\",\"displayedCrc32\":\"");
  json += hex32(displayState.displayedFrameCrc);
  json += F("\"},\"storage\":{\"mounted\":");
  json += boolJson(storageMounted);
  json += F(",\"partitionLabel\":\"");
  json += jsonEscape(storagePartitionLabel);
  json += F("\",\"formattedOnBoot\":");
  json += boolJson(storageFormattedOnBoot);
  json += F(",\"error\":\"");
  json += jsonEscape(storageError);
  json += F("\",\"totalBytes\":");
  json += storageMounted ? LittleFS.totalBytes() : 0;
  json += F(",\"usedBytes\":");
  json += storageMounted ? LittleFS.usedBytes() : 0;
  json += F("},\"screen\":{\"profileId\":\"");
  json += muti::config::kProfileId;
  json += F("\",\"model\":\"");
  json += muti::config::kDisplayModel;
  json += F("\",\"palette\":\"");
  json += muti::config::kPaletteId;
  json += F("\",\"width\":960,\"height\":640,\"colors\":4,\"frameBytes\":153600,\"controller\":\"SSD2677\",\"partialRefresh\":false}}\n");
  return json;
}

void serveUi() {
  server.sendHeader("Content-Encoding", "gzip");
  server.sendHeader("Cache-Control", "no-store");
  server.sendHeader("X-Content-Type-Options", "nosniff");
  server.sendHeader("Referrer-Policy", "no-referrer");
  server.sendHeader("Content-Security-Policy",
                    "default-src 'self' data: blob:; connect-src 'self'; img-src 'self' data: blob:; "
                    "style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; object-src 'none'");
  server.send_P(200, "text/html; charset=utf-8", reinterpret_cast<PGM_P>(WEB_UI_GZ), WEB_UI_GZ_LEN);
}

void setupWebServer() {
  server.enableCORS(true);
  const char* headers[] = {"X-Frame-CRC32"};
  server.collectHeaders(headers, 1);

  server.on("/", HTTP_GET, serveUi);
  server.on("/generate_204", HTTP_ANY, serveUi);
  server.on("/hotspot-detect.html", HTTP_ANY, serveUi);
  server.on("/connecttest.txt", HTTP_ANY, serveUi);
  server.on("/ncsi.txt", HTTP_ANY, serveUi);

  server.on("/api/status", HTTP_GET, []() { sendJson(200, statusJson()); });

  server.on("/api/wifi/scan", HTTP_GET, []() {
    if (server.hasArg("start") && server.arg("start") == "1") startWifiScan();
    String body = String("{\"ok\":true,\"scanning\":") + boolJson(scanActive) +
                  ",\"networks\":" + scanCacheJson + "}";
    sendJson(200, body);
  });

  server.on("/api/wifi/save", HTTP_POST, []() {
    String ssid = server.arg("ssid");
    const String password = server.arg("password");
    ssid.trim();
    if (ssid.isEmpty() || ssid.length() > 32 || password.length() > 64) {
      sendJson(400, F("{\"ok\":false,\"error\":\"SSID或密码长度无效\"}"));
      return;
    }
    settings.staSsid = ssid;
    settings.staPassword = password;
    settings.staticIpEnabled = server.arg("ipMode") == "static";
    settings.staticIp = server.arg("staticIp");
    settings.gateway = server.arg("gateway");
    settings.subnet = server.arg("subnet");
    settings.dns1 = server.arg("dns1");
    settings.staticIp.trim(); settings.gateway.trim(); settings.subnet.trim(); settings.dns1.trim();
    if (settings.subnet.isEmpty()) settings.subnet = "255.255.255.0";
    String staticError;
    if (!validateStaticNetwork(staticError)) {
      sendJson(400, String("{\"ok\":false,\"error\":\"") + jsonEscape(staticError) + "\"}");
      return;
    }
    saveSettings();
    if (server.arg("showInfo") == "1") saveNetworkInfoPending(true);
    scheduleNetworkAction(PendingNetworkAction::StartSta, muti::config::kNetworkSwitchDelayMs);
    const String message = settings.staticIpEnabled ? String("已保存，将使用固定IP ") + settings.staticIp : String("已保存，将通过DHCP连接 ") + ssid;
    sendJson(200, String("{\"ok\":true,\"message\":\"") + jsonEscape(message) + "\"}");
  });

  server.on("/api/wifi/forget", HTTP_POST, []() {
    settings.staSsid = "";
    settings.staPassword = "";
    saveSettings();
    scheduleNetworkAction(PendingNetworkAction::StartAp, muti::config::kNetworkSwitchDelayMs);
    sendJson(200, F("{\"ok\":true,\"message\":\"已忘记局域网，将保持配置热点\"}"));
  });

  server.on("/api/network/sta", HTTP_POST, []() {
    if (settings.staSsid.isEmpty()) {
      sendJson(409, F("{\"ok\":false,\"error\":\"没有已保存的局域网配置\"}"));
      return;
    }
    scheduleNetworkAction(PendingNetworkAction::StartSta, muti::config::kNetworkSwitchDelayMs);
    sendJson(200, String("{\"ok\":true,\"message\":\"将关闭配置热点并连接 ") +
                      jsonEscape(settings.staSsid) + "\"}");
  });

  server.on("/api/network/ap", HTTP_POST, []() {
    scheduleNetworkAction(PendingNetworkAction::StartAp, muti::config::kNetworkSwitchDelayMs);
    sendJson(200, String("{\"ok\":true,\"message\":\"将关闭局域网并开启配置热点 ") +
                      jsonEscape(settings.apName) + "\"}");
  });

  server.on("/api/device/save", HTTP_POST, []() {
    String deviceName = server.arg("deviceName");
    String requestedHostname = normalizeHostname(server.arg("hostname"));
    String apName = server.arg("apName");
    deviceName.trim(); apName.trim();
    if (deviceName.isEmpty() || deviceName.length() > 48 || apName.isEmpty() || apName.length() > 31) {
      sendJson(400, F("{\"ok\":false,\"error\":\"设备名或热点名长度无效\"}"));
      return;
    }
    if (!validHostname(requestedHostname)) {
      sendJson(400, F("{\"ok\":false,\"error\":\"主机名只能包含小写字母、数字和连字符，最长31位\"}"));
      return;
    }
    const bool networkIdentityChanged = settings.apName != apName || settings.hostname != requestedHostname;
    settings.deviceName = deviceName; settings.apName = apName; settings.hostname = requestedHostname; hostname = settings.hostname;
    saveSettings();
    if (server.arg("showInfo") == "1") { saveNetworkInfoPending(true); networkInfoReadyAtMs = millis() + muti::config::kNetworkInfoDelayMs; }
    if (networkIdentityChanged) {
      scheduleNetworkAction(networkState == NetworkState::ApPortal ? PendingNetworkAction::StartAp : PendingNetworkAction::StartSta, muti::config::kNetworkSwitchDelayMs);
      sendJson(200, String("{\"ok\":true,\"message\":\"设置已保存，新地址为 http://") + jsonEscape(settings.hostname) + ".local/\"}");
    } else sendJson(200, F("{\"ok\":true,\"message\":\"设置已保存\"}"));
  });

  server.on("/api/upload", HTTP_POST, handleUploadComplete, handleUploadChunk);

  server.on("/api/action", HTTP_POST, []() {
    const String action = server.arg("action");
    if (displayState.displaying) {
      sendJson(409, F("{\"ok\":false,\"error\":\"屏幕正在刷新\"}"));
      return;
    }
    if (epd.faultLatched() && action != "reboot") {
      sendJson(423, F("{\"ok\":false,\"error\":\"驱动故障已锁定，需物理断电30秒\"}"));
      return;
    }
    if (action == "reboot") {
      restartAtMs = millis() + 800;
      sendJson(200, F("{\"ok\":true,\"message\":\"设备将重启\"}"));
      return;
    }
    if (action == "refresh") {
      if (!storageMounted) {
        sendJson(503, String("{\"ok\":false,\"error\":\"") + jsonEscape(storageError.isEmpty() ? "LittleFS未挂载" : storageError) + "\"}");
        return;
      }
      if (!LittleFS.exists(muti::config::kFramePath)) {
        sendJson(404, F("{\"ok\":false,\"error\":\"frame.bin不存在\"}"));
        return;
      }
      displayState.pending = true;
      displayState.queuedAtMs = millis();
      displayState.message = "已请求重新显示当前帧";
      sendJson(200, F("{\"ok\":true,\"queued\":true}"));
      return;
    }

    PatternKind kind;
    if (action == "raw") kind = PatternKind::Raw;
    else if (action == "palette") kind = PatternKind::Palette;
    else if (action == "gray") kind = PatternKind::Gray16;
    else if (action == "white") kind = PatternKind::White;
    else if (action == "network") kind = PatternKind::NetworkInfo;
    else {
      sendJson(400, F("{\"ok\":false,\"error\":\"未知操作\"}"));
      return;
    }
    uint32_t crc = 0;
    if (!generatePattern(kind, crc)) {
      if (!storageMounted) {
        sendJson(503, String("{\"ok\":false,\"error\":\"") + jsonEscape(storageError.isEmpty() ? "LittleFS未挂载" : storageError) + "\"}");
      } else {
        sendJson(500, F("{\"ok\":false,\"error\":\"测试帧生成失败\"}"));
      }
      return;
    }
    String body = String("{\"ok\":true,\"crc32\":\"") + hex32(crc) +
                  "\",\"queued\":" + boolJson(displayState.pending) + "}";
    sendJson(200, body);
  });

  server.on("/frame.bin", HTTP_GET, []() {
    if (!storageMounted) {
      server.send(503, "text/plain; charset=utf-8", storageError.isEmpty() ? "LittleFS未挂载" : storageError);
      return;
    }
    File file = LittleFS.open(muti::config::kFramePath, FILE_READ);
    if (!file) {
      server.send(404, "text/plain; charset=utf-8", "frame.bin不存在");
      return;
    }
    server.sendHeader("Content-Disposition", "attachment; filename=frame.bin");
    server.sendHeader("Cache-Control", "no-store");
    server.sendHeader("X-Muti-Device-ID", deviceId);
    server.streamFile(file, "application/octet-stream");
    file.close();
  });

  server.onNotFound([]() {
    if (server.method() == HTTP_OPTIONS) {
      server.sendHeader("Access-Control-Allow-Origin", "*");
      server.sendHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
      server.sendHeader("Access-Control-Allow-Headers", "Content-Type,X-Frame-CRC32");
      server.send(204);
      return;
    }
    serveUi();
  });
  server.begin();
  Serial.println(F("[WEB] HTTP server started"));
}

bool tryMountStorageLabel(const char* label, bool allowFormatRecovery) {
  Serial.printf("[FS] try label=%s base=%s format-recovery=%s\n", label,
                muti::config::kLittleFsBasePath, allowFormatRecovery ? "yes" : "no");
  if (LittleFS.begin(false, muti::config::kLittleFsBasePath, 10, label)) {
    storageMounted = true;
    storageFormattedOnBoot = false;
    storagePartitionLabel = label;
    return true;
  }
  Serial.printf("[FS] label=%s mount failed\n", label);
  if (!allowFormatRecovery) {
    return false;
  }

  // begin(false, ..., label) above selects the target partition label for
  // LittleFS.format(). Formatting is delayed until both labels have already
  // failed their non-destructive probes in mountStorage().
  Serial.printf("[FS] formatting recovery label=%s\n", label);
  if (!LittleFS.format()) {
    Serial.printf("[FS] label=%s format failed\n", label);
    return false;
  }
  if (!LittleFS.begin(false, muti::config::kLittleFsBasePath, 10, label)) {
    Serial.printf("[FS] label=%s remount after format failed\n", label);
    return false;
  }
  storageMounted = true;
  storageFormattedOnBoot = true;
  storagePartitionLabel = label;
  return true;
}

void mountStorage() {
  storageMounted = false;
  storageFormattedOnBoot = false;
  storagePartitionLabel = "";
  storageError = "";

  // Compatibility order:
  //   v1.0.x/v1.1.x and v1.2.2 complete images -> label "spiffs"
  //   v1.2.0/v1.2.1 complete images           -> label "littlefs"
  // Never format until both labels have first been tried without formatting.
  if (!tryMountStorageLabel(muti::config::kLittleFsPreferredPartitionLabel, false) &&
      !tryMountStorageLabel(muti::config::kLittleFsAlternatePartitionLabel, false) &&
      !tryMountStorageLabel(muti::config::kLittleFsPreferredPartitionLabel, true) &&
      !tryMountStorageLabel(muti::config::kLittleFsAlternatePartitionLabel, true)) {
    storageError = String("LittleFS挂载失败：已尝试 ") +
                   muti::config::kLittleFsPreferredPartitionLabel + " / " +
                   muti::config::kLittleFsAlternatePartitionLabel;
    Serial.printf("[FS][ERROR] %s\n", storageError.c_str());
    return;
  }

  size_t size = 0;
  const uint32_t crc = crcFile(muti::config::kFramePath, &size);
  if (size == kFrameBytes) {
    displayState.storedFrameCrc = crc;
  } else if (size != 0) {
    Serial.printf("[FS] removing invalid frame: %u bytes\n", static_cast<unsigned>(size));
    LittleFS.remove(muti::config::kFramePath);
  }
  LittleFS.remove(muti::config::kUploadTempPath);
  LittleFS.remove(muti::config::kFrameBackupPath);
  Serial.printf("[FS] mounted label=%s formatted=%s total=%u used=%u frame=%u crc=%s\n",
                storagePartitionLabel.c_str(), storageFormattedOnBoot ? "yes" : "no",
                static_cast<unsigned>(LittleFS.totalBytes()),
                static_cast<unsigned>(LittleFS.usedBytes()),
                static_cast<unsigned>(size), hex32(displayState.storedFrameCrc).c_str());
}

}  // namespace

void setup() {
  Serial.begin(115200);
  delay(350);
  Serial.println();
  Serial.printf("[BOOT] %s v%s (%s)\n", muti::config::kFirmwareName,
                muti::config::kFirmwareVersion, muti::config::kBuildDate);
  Serial.println(F("[BOOT] display auto-refresh is disabled; use the local web UI to trigger a test"));
  Serial.printf("[BOOT] pins SCK=%d MOSI=%d CS=%d DC=%d RST=%d BUSY=%d PWR=%d\n",
                muti::config::kPinSck, muti::config::kPinMosi, muti::config::kPinCs,
                muti::config::kPinDc, muti::config::kPinRst, muti::config::kPinBusy,
                muti::config::kPinPower);

  epd.begin();
  mountStorage();
  initDeviceIdentity();
  loadSettings();
  hostname = makeHostname();
  setupWebServer();

  if (settings.staSsid.isEmpty()) startApPortal();
  else startStaConnection();
}

void loop() {
  server.handleClient();
  manageNetwork();
  processPendingNetworkInfo();
  processPendingDisplay();

  if (restartAtMs != 0 && static_cast<int32_t>(millis() - restartAtMs) >= 0) {
    Serial.println(F("[SYS] restarting"));
    delay(50);
    ESP.restart();
  }
  delay(1);
}
