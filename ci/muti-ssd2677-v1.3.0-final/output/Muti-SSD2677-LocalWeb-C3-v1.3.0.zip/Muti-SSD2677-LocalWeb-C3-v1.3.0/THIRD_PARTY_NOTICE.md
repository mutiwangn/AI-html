# Third-party notice

The SSD2677 waveform byte tables are hardware-specific reference data derived from prior project work and a community reference implementation. No broad license grant for unrelated commercial redistribution is asserted by this package. Verify the upstream repository, panel vendor agreement, fonts, images, and all other third-party assets before commercial distribution.
