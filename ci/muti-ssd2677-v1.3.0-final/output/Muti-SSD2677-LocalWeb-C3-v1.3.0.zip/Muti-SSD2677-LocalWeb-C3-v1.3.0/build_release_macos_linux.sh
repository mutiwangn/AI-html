#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m platformio run -e c3_promini_usb
python3 tools/make_release.py --env c3_promini_usb
printf '\nBuild complete. See firmware/\n'
