# Muti-SSD2677-LocalWeb-C3 v1.2.1

> **v1.2.1 修复：** v1.2.0 的分区标签为 `littlefs`，Arduino-ESP32 2.0.17 默认查找 `spiffs`，导致网页可打开但 `/upload.tmp` 无法创建。若已完整烧录 v1.2.0，只需把 v1.2.1 `firmware.bin` 写到 `0x10000`，无需擦除 NVS/分区表。


## 1. 版本用途

面向以下固定组合：

- ESP32-C3 Pro Mini；
- 10.2 英寸、960×640、黑/白/黄/红四色墨水屏；
- SSD2677 控制器；
- GPIO：SCK 4、MOSI 6、CS 7、DC 1、RST 2、BUSY 10；
- RESE：3 Ω；
- 无 PWR GPIO。

本版取消服务器、域名、FastAPI、远程 `frame.bin` 拉取和 TRMNL 运行时。图片、月历、裁切、旋转、四色量化、蛇形 Floyd–Steinberg、2bpp 打包和 CRC 均在浏览器内完成。

## 2. 安全边界

固件启动后**不会自动刷新墨水屏**。先验证串口、配置热点和网页，再手动触发测试图。

固定底层参数：

```text
PSR   = 9F A9
VCOM  = 9C
VBD   = 37
LUT   = TB hybrid（W3 主体 + W1 rows 4–7、20–23、36–39）
颜色  = 0黑 / 1白 / 2黄 / 3红
帧长  = 153600 B
冷却  = 180 s
```

不要在本工程中改为内部 OTP，不要使用 `0x5F/0x57`，不要把 RST 改到 GPIO3。

BUSY 超时后固件会锁定刷新。此时必须同时断开 USB 和驱动板供电至少 30 秒。

## 3. 直接烧录预编译镜像

Windows PowerShell/CMD：

```bat
flash_windows.bat COM10
```

等价命令：

```powershell
py -m esptool --chip esp32c3 --port COM10 --baud 115200 write-flash 0x0 firmware\merged-flash.bin
```

只想升级应用且保留 NVS 与 LittleFS：

```powershell
py -m esptool --chip esp32c3 --port COM10 --baud 115200 write-flash 0x10000 firmware\firmware.bin
```

完整镜像会覆盖应用、分区和启动文件，但 `merged-flash.bin` 中未填充的地址由 esptool 写入策略决定。首次测试建议先备份，或仅写 `0x10000 firmware.bin`。

## 4. PlatformIO 编译与上传

```powershell
cd Muti-SSD2677-LocalWeb-C3-v1.2.1
py -m platformio run -e c3_promini_usb
py -m platformio run -e c3_promini_usb -t upload --upload-port COM10
```

UART 转接器环境：

```powershell
py -m platformio run -e c3_promini_uart -t upload --upload-port COM10
```

## 5. 首次启动

1. 串口波特率 115200。
2. 没有已保存 Wi‑Fi 时，设备启动开放热点 `Muti-10.2`。
3. 手机或电脑连接热点。
4. 浏览器打开 `192.168.4.1`。
5. 先查看“设备”页，确认 BUSY 引脚没有故障锁定。
6. 首次屏幕测试优先选择“原始码 0/1/2/3”。
7. 颜色应从左到右为黑、白、黄、红。
8. 等待刷新完成后至少 180 秒，再执行下一次全刷。

## 6. 加入局域网

1. “设备”→“扫描 Wi‑Fi”；
2. 选择 2.4 GHz SSID；
3. 输入密码并保存；
4. 设备重启并以 STA-only 连接；
5. 成功后通过设备 IP 或 `muti-102-xxxx.local` 访问；
6. 20 秒内连接失败，设备自动恢复 `Muti-10.2` 热点。

建议先用独立测试热点：

```text
SSID: MutiTest24
密码: 12345678
2.4 GHz / WPA2-AES
```

## 7. 传图

1. 选择 JPG、PNG 或 WebP；
2. 选择“完整显示”或“铺满裁切”；
3. 选择旋转角度；
4. 点击“生成四色预览”；
5. 检查 153600 B 和 CRC32；
6. 点击“上传并刷新屏幕”。

浏览器仅上传最终 2bpp 帧，不上传原图。
