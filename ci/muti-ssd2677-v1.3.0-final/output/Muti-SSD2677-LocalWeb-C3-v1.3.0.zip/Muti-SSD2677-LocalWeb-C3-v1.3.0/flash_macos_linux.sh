#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /dev/ttyACM0" >&2
  exit 2
fi
[[ -f firmware/merged-flash.bin ]] || { echo "merged-flash.bin missing; run build_release_macos_linux.sh first" >&2; exit 3; }
python3 -m esptool --chip esp32c3 --port "$1" --baud 115200 write-flash 0x0 firmware/merged-flash.bin
