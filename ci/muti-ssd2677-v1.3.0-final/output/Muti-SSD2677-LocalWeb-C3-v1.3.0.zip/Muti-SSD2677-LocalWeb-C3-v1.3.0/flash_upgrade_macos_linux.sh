#!/usr/bin/env bash
set -euo pipefail
PORT="${1:-/dev/ttyACM0}"
python3 -m esptool --chip esp32c3 --port "$PORT" --baud 115200 write-flash 0x10000 firmware/firmware.bin
