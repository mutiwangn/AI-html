#!/usr/bin/env python3
"""Offline structural regression checks for Muti SSD2677 LocalWeb v1.3.0."""
from __future__ import annotations

import gzip
import hashlib
import re
import shutil
import subprocess
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []


def require(condition: bool, message: str) -> None:
    if not condition:
        ERRORS.append(message)


required_files = [
    "platformio.ini",
    "partitions_4mb.csv",
    "include/app_config.h",
    "include/lut_profiles.h",
    "include/web_ui.h",
    "include/epd_ssd2677_tb.h",
    "src/main.cpp",
    "src/epd_ssd2677_tb.cpp",
    "web/index.html",
    "tools/embed_web.py",
    "tools/make_release.py",
    "README_烧录说明.md",
    "docs/NETWORK.md",
    "docs/API.md",
]
for rel in required_files:
    require((ROOT / rel).is_file(), f"missing required file: {rel}")

require(not (ROOT / "host").exists(), "host/ must not exist")
require(not (ROOT / "trmnl").exists(), "trmnl/ must not exist")

html = (ROOT / "web/index.html").read_text(encoding="utf-8")
main_cpp = (ROOT / "src/main.cpp").read_text(encoding="utf-8")
config = (ROOT / "include/app_config.h").read_text(encoding="utf-8")
parts = (ROOT / "partitions_4mb.csv").read_text(encoding="utf-8")

runtime_paths = [ROOT / "src", ROOT / "include", ROOT / "web", ROOT / "platformio.ini"]
runtime_texts: list[str] = []
for base in runtime_paths:
    if base.is_file():
        runtime_texts.append(base.read_text(encoding="utf-8", errors="ignore"))
    elif base.is_dir():
        runtime_texts.extend(
            path.read_text(encoding="utf-8", errors="ignore")
            for path in base.rglob("*")
            if path.is_file() and path.suffix.lower() in {".cpp", ".h", ".html", ".js", ".ini"}
        )
runtime_combined = "\n".join(runtime_texts)
for token in ["remoteUrl", "HTTPClient.h", "FastAPI", "Playwright", "current_frame.bin"]:
    require(token not in runtime_combined, f"forbidden server/remote token remains: {token}")

# No runtime dependency on the public Internet.
for token in ['src="http', 'href="http', 'fetch("http', "fetch('http"]:
    require(token not in html, f"external runtime URL in UI: {token}")

# Release identity and frame contract.
require('kFirmwareVersion[] = "1.3.0"' in config, "firmware version is not 1.3.0")
require("kSettingsVersion = 4" in config, "settings schema is not 4")
require('kProfileId[] = "ssd2677-960x640-4c"' in config, "device profile ID changed")
require('kPaletteId[] = "bwry"' in config, "palette ID changed")
require("FRAME_BYTES=153600" in html, "browser frame byte constant changed")
require("packed[p>>2]|=codes[p]<<(6-((p&3)*2))" in html, "2bpp packing expression changed")
require("kFrameBytes = 153600" in config, "firmware frame byte constant changed")

# Stable device identity and multi-screen network controls.
for token in [
    "ESP.getEfuseMac()",
    "deviceId",
    "shortId",
    "macAddressText",
    "defaultUniqueHostname",
    "defaultUniqueApName",
    "settings.hostname",
    'preferences.putString("hostname"',
    'preferences.putBool("staticEn"',
    'preferences.putString("staticIp"',
    'server.on("/api/device/save"',
    'server.on("/api/wifi/save"',
    'server.on("/api/network/sta"',
    'server.on("/api/network/ap"',
    'PatternKind::NetworkInfo',
    'action == "network"',
    'MDNS.addService("muti-epd", "tcp"',
    'MDNS.addServiceTxt("muti-epd", "tcp", "id"',
    'MDNS.addServiceTxt("muti-epd", "tcp", "profile"',
    'server.enableCORS(true)',
    'server.sendHeader("X-Muti-Device-ID"',
]:
    require(token in main_cpp, f"multi-device feature missing: {token}")

for token in [
    'id="hostnameInput"',
    'id="ipMode"',
    'id="staticIp"',
    'id="gateway"',
    'id="subnet"',
    'id="dns1"',
    'id="showInfoAfterConnect"',
    'data-action="network"',
    "设备 ID",
    "多块屏幕",
    "路由器地址保留",
]:
    require(token in html, f"multi-device UI missing: {token}")

# Static IPv4 is configured before Wi-Fi begin; DHCP reset path remains.
static_pos = main_cpp.find("WiFi.config(ip, gateway, subnet, dns)")
begin_pos = main_cpp.find("WiFi.begin(settings.staSsid.c_str()")
require(static_pos >= 0 and begin_pos >= 0 and static_pos < begin_pos, "static IPv4 must be set before WiFi.begin")
require("WiFi.config(IPAddress(), IPAddress(), IPAddress())" in main_cpp, "DHCP restore path missing")
require("subnetMaskIsValid" in main_cpp and "sameIpv4Subnet" in main_cpp, "static IPv4 validation missing")

# Wi-Fi/AP recovery and compatibility migrations.
require("WiFi.softAPConfig(apIp, apIp, subnet)" in main_cpp, "explicit AP address missing")
require("for (uint8_t attempt = 1; attempt <= 3" in main_cpp, "AP retry loop missing")
require('preferences.getString("ssid", "")' in main_cpp, "legacy SSID migration missing")
require('preferences.getString("pass", "")' in main_cpp, "legacy password migration missing")
require('kLittleFsPreferredPartitionLabel[] = "spiffs"' in config, "preferred LittleFS label missing")
require('kLittleFsAlternatePartitionLabel[] = "littlefs"' in config, "alternate LittleFS label missing")
mount_order = [
    "kLittleFsPreferredPartitionLabel, false",
    "kLittleFsAlternatePartitionLabel, false",
    "kLittleFsPreferredPartitionLabel, true",
    "kLittleFsAlternatePartitionLabel, true",
]
require(all(token in main_cpp for token in mount_order), "dual-label LittleFS calls missing")
if all(token in main_cpp for token in mount_order):
    positions = [main_cpp.index(token) for token in mount_order]
    require(positions == sorted(positions), "LittleFS probing/format order is unsafe")
require(
    re.search(r"^spiffs\s*,\s*data\s*,\s*spiffs\s*,\s*0x210000\s*,\s*0x1E0000", parts, re.M)
    is not None,
    "partition table changed",
)

# Display driver and LUT are frozen for this network/identity-only release.
frozen_hashes = {
    "src/epd_ssd2677_tb.cpp": "009aa6bae952e9b959dfa982594cecb96fcb8cbe8fe17b0a9a7d41e8f39f0d20",
    "include/epd_ssd2677_tb.h": "e11cc9e2ce988358ac6d230eb6a6f7063716f71e06672680b23865f0fd649187",
    "include/lut_profiles.h": "6abb95eff6e9b9715a66971e07d658f44d33f82695bf5d63c0e6ac4b4c73de8e",
}
for rel, expected in frozen_hashes.items():
    actual = hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()
    require(actual == expected, f"frozen display baseline changed: {rel}: {actual}")

lut_text = (ROOT / "include/lut_profiles.h").read_text(encoding="utf-8")
for name, expected_crc in [("kE5Wsf1", 0xDEA3DF46), ("kE5Wsf", 0xE086FA09)]:
    match = re.search(name + r"\[535\].*?\{(.*?)\};", lut_text, re.S)
    require(match is not None, f"cannot parse {name}")
    if match:
        data = bytes(int(value, 16) for value in re.findall(r"0x([0-9A-Fa-f]{2})", match.group(1)))
        require(len(data) == 535, f"{name} length changed: {len(data)}")
        require((zlib.crc32(data) & 0xFFFFFFFF) == expected_crc, f"{name} CRC changed")

# Embedded Web UI must exactly match web/index.html.
header_text = (ROOT / "include/web_ui.h").read_text(encoding="utf-8")
data_match = re.search(r"WEB_UI_GZ\[.*?\].*?\{(.*?)\};", header_text, re.S)
sha_match = re.search(r'WEB_UI_SOURCE_SHA256\[\] = "([0-9a-f]{64})"', header_text)
require(data_match is not None and sha_match is not None, "cannot parse embedded web UI")
if data_match and sha_match:
    compressed = bytes(int(value, 16) for value in re.findall(r"0x([0-9A-Fa-f]{2})", data_match.group(1)))
    decoded = gzip.decompress(compressed)
    source = (ROOT / "web/index.html").read_bytes()
    require(decoded == source, "embedded Web UI is stale")
    require(hashlib.sha256(decoded).hexdigest() == sha_match.group(1), "embedded Web UI SHA mismatch")

# Browser script syntax.
node = shutil.which("node")
if node:
    scripts = re.findall(r"<script>(.*?)</script>", html, re.S)
    require(bool(scripts), "inline JavaScript missing")
    if scripts:
        target = ROOT / "tests" / "web-inline-check.js"
        target.parent.mkdir(exist_ok=True)
        target.write_text(scripts[-1], encoding="utf-8")
        result = subprocess.run([node, "--check", str(target)], capture_output=True, text=True)
        require(result.returncode == 0, "JavaScript syntax error: " + result.stderr.strip())

for error in ERRORS:
    print("ERROR:", error)
if ERRORS:
    raise SystemExit(1)
print("PASS: v1.3.0 structural validation")
