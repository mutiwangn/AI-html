Import("env")

from pathlib import Path
import subprocess

project_dir = Path(env.subst("$PROJECT_DIR"))
python_exe = env.subst("$PYTHONEXE")
subprocess.check_call([python_exe, str(project_dir / "tools" / "embed_web.py")])
