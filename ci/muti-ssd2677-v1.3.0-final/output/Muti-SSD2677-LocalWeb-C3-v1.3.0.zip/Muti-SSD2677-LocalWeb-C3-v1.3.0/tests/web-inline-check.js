
'use strict';
const W=960,H=640,FRAME_BYTES=153600;
const PALETTE=[
 {code:0,name:'黑',rgb:[24,24,22]},
 {code:1,name:'白',rgb:[249,247,238]},
 {code:2,name:'黄',rgb:[224,169,35]},
 {code:3,name:'红',rgb:[181,43,38]}
];
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const previewCanvas=$('#previewCanvas'), previewCtx=previewCanvas.getContext('2d',{willReadFrequently:true});
const workCanvas=document.createElement('canvas');workCanvas.width=W;workCanvas.height=H;
const workCtx=workCanvas.getContext('2d',{willReadFrequently:true});
const calCanvas=$('#calendarCanvas'),calCtx=calCanvas.getContext('2d',{willReadFrequently:true});
let sourceImage=null, fitMode='contain',rotation=0,imageFrame=null,calendarFrame=null,lastStatus=null,statusTimer=null;
let networkFormTouched=false,identityFormTouched=false;

function setMessage(id,text,type=''){const el=$(id);el.textContent=text;el.className='message'+(type?' '+type:'')}
function progress(id,value){$(id).style.width=Math.max(0,Math.min(100,value))+'%'}
function setBusy(show,title='处理中',text='请勿关闭页面'){const o=$('#busyOverlay');o.classList.toggle('show',show);$('#busyTitle').textContent=title;$('#busyText').textContent=text}
function formatMs(ms){if(!ms)return '0 秒';if(ms<1000)return ms+' ms';return (ms/1000).toFixed(ms<10000?1:0)+' 秒'}
function formatBytes(n){if(!Number.isFinite(n))return '—';if(n<1024)return n+' B';return (n/1024).toFixed(1)+' KiB'}
function hex32(n){return (n>>>0).toString(16).toUpperCase().padStart(8,'0')}
function clamp(v){return v<0?0:v>255?255:v}

const crcTable=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);t[n]=c>>>0}return t})();
function crc32(bytes){let c=0xFFFFFFFF;for(let i=0;i<bytes.length;i++)c=crcTable[(c^bytes[i])&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0}

function selectSegment(container,value){container.querySelectorAll('button').forEach(b=>b.classList.toggle('active',String(b.dataset.value)===String(value)))}
$('#fitSeg').addEventListener('click',e=>{if(e.target.dataset.value){fitMode=e.target.dataset.value;selectSegment($('#fitSeg'),fitMode)}});
$('#rotateSeg').addEventListener('click',e=>{if(e.target.dataset.value){rotation=Number(e.target.dataset.value);selectSegment($('#rotateSeg'),rotation)}});
$$('.tab').forEach(b=>b.addEventListener('click',()=>{$$('.tab').forEach(x=>x.classList.toggle('active',x===b));$$('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+b.dataset.page))}));

function placeholder(ctx,title,subtitle){ctx.fillStyle='#f9f7ee';ctx.fillRect(0,0,W,H);ctx.strokeStyle='#181816';ctx.lineWidth=4;ctx.strokeRect(24,24,W-48,H-48);ctx.fillStyle='#181816';ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='700 54px system-ui,sans-serif';ctx.fillText(title,W/2,H/2-30);ctx.font='28px system-ui,sans-serif';ctx.fillStyle='#66645f';ctx.fillText(subtitle,W/2,H/2+40)}
placeholder(previewCtx,'Muti 10.2 四色','选择图片后在浏览器本地处理');
placeholder(calCtx,'本地月历','设置年月后生成');

async function loadImageFile(file){
 if(!file)return;
 if(!/^image\/(png|jpeg|webp)$/.test(file.type)){setMessage('#imageMessage','仅支持 JPG、PNG、WebP。','error');return}
 setBusy(true,'读取图片','原图不会离开当前浏览器');
 try{
  if('createImageBitmap'in window)sourceImage=await createImageBitmap(file,{imageOrientation:'from-image'});
  else sourceImage=await new Promise((resolve,reject)=>{const img=new Image();const u=URL.createObjectURL(file);img.onload=()=>{URL.revokeObjectURL(u);resolve(img)};img.onerror=reject;img.src=u});
  $('#processBtn').disabled=false;$('#uploadBtn').disabled=true;imageFrame=null;
  setMessage('#imageMessage',`已读取 ${sourceImage.width} × ${sourceImage.height}，点击“生成四色预览”。`,'ok');
 }catch(err){setMessage('#imageMessage','图片读取失败：'+err.message,'error')}
 finally{setBusy(false)}
}
$('#imageFile').addEventListener('change',e=>loadImageFile(e.target.files[0]));
const drop=$('#dropZone');
['dragenter','dragover'].forEach(n=>drop.addEventListener(n,e=>{e.preventDefault();drop.classList.add('drag')}));
['dragleave','drop'].forEach(n=>drop.addEventListener(n,e=>{e.preventDefault();drop.classList.remove('drag')}));
drop.addEventListener('drop',e=>loadImageFile(e.dataTransfer.files[0]));

function drawSourceToWork(image){
 workCtx.save();workCtx.setTransform(1,0,0,1,0,0);workCtx.fillStyle='#fff';workCtx.fillRect(0,0,W,H);
 const sw=image.width,sh=image.height,rad=rotation*Math.PI/180,rotated=rotation%180!==0;
 const rw=rotated?sh:sw,rh=rotated?sw:sh;
 const scale=fitMode==='cover'?Math.max(W/rw,H/rh):Math.min(W/rw,H/rh);
 workCtx.translate(W/2,H/2);workCtx.rotate(rad);workCtx.scale(scale,scale);workCtx.imageSmoothingEnabled=true;workCtx.imageSmoothingQuality='high';workCtx.drawImage(image,-sw/2,-sh/2);workCtx.restore();
 return workCtx.getImageData(0,0,W,H);
}

function nearestPalette(r,g,b){
 let best=0,bestD=Infinity;
 for(let i=0;i<PALETTE.length;i++){const p=PALETTE[i].rgb,dr=r-p[0],dg=g-p[1],db=b-p[2],d=.30*dr*dr+.56*dg*dg+.14*db*db;if(d<bestD){bestD=d;best=i}}
 return best;
}

async function quantizeFloyd(imageData,targetCtx,progressId){
 const src=imageData.data,codes=new Uint8Array(W*H),out=new ImageData(W,H),dst=out.data;
 let curr=new Float32Array((W+2)*3),next=new Float32Array((W+2)*3);
 const contrast=1.05;
 for(let y=0;y<H;y++){
  next.fill(0);const dir=(y&1)?-1:1;let x=dir===1?0:W-1;
  for(let step=0;step<W;step++,x+=dir){
   const s=(y*W+x)*4,e=(x+1)*3;
   let r=clamp((src[s]-128)*contrast+128+curr[e]);
   let g=clamp((src[s+1]-128)*contrast+128+curr[e+1]);
   let b=clamp((src[s+2]-128)*contrast+128+curr[e+2]);
   const luma=.2126*r+.7152*g+.0722*b,chroma=Math.max(r,g,b)-Math.min(r,g,b);
   const whiteProtect=luma>=247&&chroma<=10;
   const pi=whiteProtect?1:nearestPalette(r,g,b),p=PALETTE[pi].rgb,gain=whiteProtect?.2:1;
   codes[y*W+x]=PALETTE[pi].code;dst[s]=p[0];dst[s+1]=p[1];dst[s+2]=p[2];dst[s+3]=255;
   const er=(r-p[0])*gain,eg=(g-p[1])*gain,eb=(b-p[2])*gain;
   const add=(arr,idx,w)=>{arr[idx]+=er*w;arr[idx+1]+=eg*w;arr[idx+2]+=eb*w};
   if(dir===1){add(curr,e+3,7/16);add(next,e-3,3/16);add(next,e,5/16);add(next,e+3,1/16)}
   else{add(curr,e-3,7/16);add(next,e+3,3/16);add(next,e,5/16);add(next,e-3,1/16)}
  }
  [curr,next]=[next,curr];
  if((y&31)===31){progress(progressId,10+75*(y+1)/H);await new Promise(r=>setTimeout(r,0))}
 }
 targetCtx.putImageData(out,0,0);
 const packed=new Uint8Array(FRAME_BYTES);for(let p=0;p<codes.length;p++)packed[p>>2]|=codes[p]<<(6-((p&3)*2));
 progress(progressId,95);const crc=crc32(packed);progress(progressId,100);return{bytes:packed,crc};
}

async function processImage(){
 if(!sourceImage)return;$('#processBtn').disabled=true;$('#uploadBtn').disabled=true;progress('#imageProgress',3);setBusy(true,'四色量化中','固定调色板 + 蛇形 Floyd–Steinberg');
 try{const source=drawSourceToWork(sourceImage);imageFrame=await quantizeFloyd(source,previewCtx,'#imageProgress');$('#frameBytes').textContent=formatBytes(imageFrame.bytes.length);$('#frameCrc').textContent=hex32(imageFrame.crc);$('#uploadBtn').disabled=false;setMessage('#imageMessage','预览完成。所见颜色就是将要打包的四种逻辑颜色。','ok')}
 catch(err){setMessage('#imageMessage','处理失败：'+err.message,'error');progress('#imageProgress',0)}
 finally{$('#processBtn').disabled=false;setBusy(false)}
}
$('#processBtn').addEventListener('click',processImage);

async function fetchJson(url,options={}){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),options.timeout||25000);try{const r=await fetch(url,{...options,signal:controller.signal,cache:'no-store'});const text=await r.text();let data;try{data=JSON.parse(text)}catch{throw new Error('设备返回非JSON：'+text.slice(0,120))}if(!r.ok||data.ok===false)throw new Error(data.error||('HTTP '+r.status));return data}finally{clearTimeout(timer)}
}
async function uploadFrame(frame,messageId,progressId){
 if(!frame)return;if(lastStatus?.display?.fault)throw new Error('设备处于故障锁定状态，需物理断电30秒');
 progress(progressId,2);setBusy(true,'上传 153600 字节','上传完成后设备会按冷却策略刷新');
 try{const form=new FormData();form.append('frame',new Blob([frame.bytes],{type:'application/octet-stream'}),'frame.bin');progress(progressId,12);const data=await fetchJson('/api/upload',{method:'POST',body:form,headers:{'X-Frame-CRC32':hex32(frame.crc)},timeout:60000});progress(progressId,100);let text=data.sameFrame?'设备确认画面相同，已跳过刷新。':'帧已保存并进入刷新队列。';if(data.cooldownRemainingMs)text+=` 剩余冷却 ${formatMs(data.cooldownRemainingMs)}。`;setMessage(messageId,text,'ok');await pollStatus()}
 catch(err){setMessage(messageId,'上传失败：'+err.message,'error');progress(progressId,0);throw err}
 finally{setBusy(false)}
}
$('#uploadBtn').addEventListener('click',()=>uploadFrame(imageFrame,'#imageMessage','#imageProgress'));

function initCalendarControls(){const now=new Date();$('#calYear').value=now.getFullYear();for(let m=1;m<=12;m++){const o=document.createElement('option');o.value=m;o.textContent=m+' 月';if(m===now.getMonth()+1)o.selected=true;$('#calMonth').append(o)}}
function daysInMonth(y,m){return new Date(y,m,0).getDate()}
function drawCalendarSource(){
 const year=Number($('#calYear').value),month=Number($('#calMonth').value),weekStart=Number($('#calWeekStart').value),showAdjacent=$('#calAdjacent').value==='1',title=$('#calTitle').value.trim()||'月度日历';
 calCtx.setTransform(1,0,0,1,0,0);calCtx.fillStyle='#f9f7ee';calCtx.fillRect(0,0,W,H);calCtx.strokeStyle='#181816';calCtx.lineWidth=3;calCtx.strokeRect(18,18,W-36,H-36);
 calCtx.textAlign='left';calCtx.textBaseline='alphabetic';calCtx.fillStyle='#181816';calCtx.font='700 30px system-ui,sans-serif';calCtx.fillText(title,48,62);calCtx.textAlign='right';calCtx.fillStyle='#b52b26';calCtx.font='800 48px system-ui,sans-serif';calCtx.fillText(`${year} / ${String(month).padStart(2,'0')}`,W-48,66);
 const names=weekStart===1?['一','二','三','四','五','六','日']:['日','一','二','三','四','五','六'];const gx=42,gy=100,gw=W-84,gh=H-132,cw=gw/7,ch=gh/7;
 calCtx.font='700 22px system-ui,sans-serif';calCtx.textAlign='center';calCtx.textBaseline='middle';for(let c=0;c<7;c++){calCtx.fillStyle=(weekStart===1?c>=5:(c===0||c===6))?'#b52b26':'#181816';calCtx.fillText('周'+names[c],gx+cw*(c+.5),gy+ch*.5)}
 calCtx.strokeStyle='#77736b';calCtx.lineWidth=1;for(let r=1;r<=7;r++){calCtx.beginPath();calCtx.moveTo(gx,gy+r*ch);calCtx.lineTo(gx+gw,gy+r*ch);calCtx.stroke()}for(let c=0;c<=7;c++){calCtx.beginPath();calCtx.moveTo(gx+c*cw,gy+ch);calCtx.lineTo(gx+c*cw,gy+gh);calCtx.stroke()}
 const firstDay=new Date(year,month-1,1).getDay(),offset=(firstDay-weekStart+7)%7,dim=daysInMonth(year,month),prevDim=daysInMonth(year,month-1);const today=new Date();
 calCtx.font='700 29px system-ui,sans-serif';for(let cell=0;cell<42;cell++){let day=cell-offset+1,cm=month,cy=year,muted=false;if(day<1){day=prevDim+day;cm=month-1;muted=true;if(cm===0){cm=12;cy--}}else if(day>dim){day-=dim;cm=month+1;muted=true;if(cm===13){cm=1;cy++}}if(muted&&!showAdjacent)continue;const row=Math.floor(cell/7)+1,col=cell%7,cx=gx+cw*(col+.5),cyy=gy+ch*(row+.5);const isToday=cy===today.getFullYear()&&cm===today.getMonth()+1&&day===today.getDate();if(isToday){calCtx.fillStyle='#e0a923';calCtx.beginPath();calCtx.arc(cx,cyy,25,0,Math.PI*2);calCtx.fill()}calCtx.fillStyle=muted?'#aaa69c':((weekStart===1?col>=5:(col===0||col===6))?'#b52b26':'#181816');calCtx.fillText(String(day),cx,cyy)}
 return calCtx.getImageData(0,0,W,H);
}
async function processCalendar(){progress('#calendarProgress',3);$('#calendarUploadBtn').disabled=true;setBusy(true,'生成月历','排版与四色量化均在浏览器内完成');try{const source=drawCalendarSource();calendarFrame=await quantizeFloyd(source,calCtx,'#calendarProgress');$('#calendarBytes').textContent=formatBytes(calendarFrame.bytes.length);$('#calendarCrc').textContent=hex32(calendarFrame.crc);$('#calendarUploadBtn').disabled=false;setMessage('#calendarMessage','月历帧生成完成。','ok')}catch(err){setMessage('#calendarMessage','生成失败：'+err.message,'error')}finally{setBusy(false)}}
$('#calendarPreviewBtn').addEventListener('click',processCalendar);$('#calendarUploadBtn').addEventListener('click',()=>uploadFrame(calendarFrame,'#calendarMessage','#calendarProgress'));

function renderStatus(s){lastStatus=s;const d=s.device,n=s.network;$('#deviceTitle').textContent=d.name;const local=n.hostname?`${n.hostname}.local`:'';$('#networkLine').textContent=`${n.mode==='ap'?'配置热点':n.mode==='sta'?'局域网':'网络连接中'} · ${n.ip}${local?' · '+local:''} · ${d.shortId}`;const dot=$('#statusDot'),txt=$('#statusText');dot.className='dot';if(s.display.fault){dot.classList.add('bad');txt.textContent='屏幕故障锁定'}else if(s.display.state==='refreshing'){dot.classList.add('warn');txt.textContent='屏幕刷新中'}else if(s.display.pending){dot.classList.add('warn');txt.textContent=s.display.cooldownRemainingMs?`冷却 ${Math.ceil(s.display.cooldownRemainingMs/1000)}s`:'等待刷新'}else{dot.classList.add('ok');txt.textContent='设备空闲'}
 if(!identityFormTouched){$('#deviceNameInput').value=d.name;$('#hostnameInput').value=n.hostname||'';$('#apNameInput').value=n.mode==='ap'?n.ssid:($('#apNameInput').value||`Muti-102-${d.shortId}`)}
 if(!networkFormTouched){$('#wifiSsid').value=n.savedSsid||$('#wifiSsid').value||'';$('#ipMode').value=n.ipMode||'dhcp';$('#staticIp').value=n.configuredIp||'';$('#gateway').value=n.configuredGateway||'';$('#subnet').value=n.configuredSubnet||n.subnet||'255.255.255.0';$('#dns1').value=n.configuredDns1||'';toggleStaticFields()}
 const apState=n.mode==='ap'?(n.apReady?'持续开放':'启动失败'):'已关闭（局域网模式）';
 const rows=[['设备 ID',d.id],['短编号',d.shortId],['MAC',d.mac],['设备配置',d.profileId],['屏幕型号',s.screen.model],['画布',`${s.screen.width}×${s.screen.height} / ${s.screen.colors}色 / ${s.screen.palette}`],['固件',`${s.firmware.name} v${s.firmware.version}`],['网络模式',n.mode],['当前SSID',n.ssid||'—'],['已保存局域网',n.savedSsid||'—'],['当前 IP',n.ip],['IP 分配',n.ipMode==='static'?`固定 ${n.configuredIp}`:'DHCP'],['网关',n.gateway||n.configuredGateway||'—'],['子网掩码',n.subnet||n.configuredSubnet||'—'],['DNS',n.dns1||n.configuredDns1||'—'],['mDNS',`${n.hostname}.local`],['配置热点',apState],['热点客户端',String(n.apClients||0)],['信号',n.mode==='sta'?n.rssi+' dBm':'—'],['地址卡待显示',n.networkInfoPending?'是':'否'],['显示状态',s.display.state],['提示',s.display.message],['BUSY 引脚',String(s.display.busyPin)],['冷却剩余',formatMs(s.display.cooldownRemainingMs)],['最后刷新',formatMs(s.display.lastRefreshMs)],['frame.bin',s.frame.exists?`${formatBytes(s.frame.bytes)} / ${s.frame.storedCrc32}`:'不存在'],['已显示 CRC',s.frame.displayedCrc32],['LittleFS',s.storage.mounted?`已挂载 (${s.storage.partitionLabel||'未知标签'}) · ${formatBytes(s.storage.usedBytes)} / ${formatBytes(s.storage.totalBytes)}${s.storage.formattedOnBoot?' · 本次启动已格式化':''}`:`未挂载 · ${s.storage.error||'未知错误'}`]];
 $('#deviceKv').innerHTML=rows.map(([a,b])=>`<dt>${escapeHtml(a)}</dt><dd>${escapeHtml(String(b))}</dd>`).join('');
 const fsOk=!!s.storage?.mounted;$$('.diag').forEach(b=>b.disabled=!fsOk||s.display.state==='refreshing'||s.display.fault);$('#uploadBtn').disabled=!imageFrame||!fsOk||s.display.state==='refreshing'||s.display.fault;$('#calendarUploadBtn').disabled=!calendarFrame||!fsOk||s.display.state==='refreshing'||s.display.fault;$('#switchStaBtn').disabled=!n.savedSsid||n.mode==='sta'||n.mode==='sta_connecting';$('#switchApBtn').disabled=n.mode==='ap';
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function pollStatus(){try{const s=await fetchJson('/api/status',{timeout:6000});renderStatus(s)}catch(err){$('#statusDot').className='dot bad';$('#statusText').textContent='设备连接失败';$('#networkLine').textContent=err.message}}
$('#refreshStatusBtn').addEventListener('click',pollStatus);

function toggleStaticFields(){$('#staticGrid').classList.toggle('hidden',$('#ipMode').value!=='static')}
['#wifiSsid','#wifiPassword','#ipMode','#staticIp','#gateway','#subnet','#dns1','#showInfoAfterConnect'].forEach(sel=>$(sel).addEventListener('input',()=>networkFormTouched=true));
['#deviceNameInput','#hostnameInput','#apNameInput','#showInfoAfterIdentity'].forEach(sel=>$(sel).addEventListener('input',()=>identityFormTouched=true));
$('#ipMode').addEventListener('change',()=>{networkFormTouched=true;toggleStaticFields()});
$('#fillCurrentIpBtn').addEventListener('click',()=>{networkFormTouched=true;if(!lastStatus)return;const n=lastStatus.network;if(!n.ip||n.ip==='0.0.0.0'||n.mode!=='sta'){setMessage('#wifiMessage','当前没有可复制的局域网地址。','error');return}$('#ipMode').value='static';toggleStaticFields();$('#staticIp').value=n.ip;$('#gateway').value=n.gateway||'';$('#subnet').value=n.subnet||'255.255.255.0';$('#dns1').value=n.dns1||n.gateway||'';setMessage('#wifiMessage',`已填入当前地址 ${n.ip}。保存前请确认该地址不会与其他设备冲突。`,'ok')});

async function scanWifi(){const btn=$('#scanWifiBtn');btn.disabled=true;setMessage('#wifiMessage','正在扫描…');try{await fetchJson('/api/wifi/scan?start=1',{timeout:8000});for(let i=0;i<16;i++){await new Promise(r=>setTimeout(r,700));const d=await fetchJson('/api/wifi/scan',{timeout:5000});if(!d.scanning){renderNetworks(d.networks);setMessage('#wifiMessage',`找到 ${d.networks.length} 个网络。`,'ok');return}}throw new Error('扫描超时')}catch(err){setMessage('#wifiMessage','扫描失败：'+err.message,'error')}finally{btn.disabled=false}}
function renderNetworks(list){$('#networkList').innerHTML='';list.sort((a,b)=>b.rssi-a.rssi).forEach(n=>{const b=document.createElement('button');b.className='network';b.innerHTML=`<span>${escapeHtml(n.ssid||'(隐藏网络)')}</span><small>${n.rssi} dBm · CH${n.channel}${n.secure?' · 加密':' · 开放'}</small>`;b.addEventListener('click',()=>{networkFormTouched=true;$('#wifiSsid').value=n.ssid;$('#wifiPassword').focus()});$('#networkList').append(b)})}
$('#scanWifiBtn').addEventListener('click',scanWifi);
$('#saveWifiBtn').addEventListener('click',async()=>{const ssid=$('#wifiSsid').value.trim(),password=$('#wifiPassword').value,ipMode=$('#ipMode').value;if(!ssid){setMessage('#wifiMessage','请输入SSID。','error');return}if(ipMode==='static'&&!$('#staticIp').value.trim()){setMessage('#wifiMessage','请输入固定IP。','error');return}const modeText=ipMode==='static'?`固定IP ${$('#staticIp').value.trim()}`:'DHCP';if(!confirm(`保存 ${ssid}，使用 ${modeText} 并切换到局域网？\n连接失败时会自动恢复配置热点。`))return;try{const body=new URLSearchParams({ssid,password,ipMode,staticIp:$('#staticIp').value.trim(),gateway:$('#gateway').value.trim(),subnet:$('#subnet').value.trim(),dns1:$('#dns1').value.trim(),showInfo:$('#showInfoAfterConnect').checked?'1':'0'});const d=await fetchJson('/api/wifi/save',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body,timeout:8000});networkFormTouched=false;setMessage('#wifiMessage',d.message,'ok')}catch(err){setMessage('#wifiMessage','保存失败：'+err.message,'error')}});
$('#forgetWifiBtn').addEventListener('click',async()=>{if(!confirm('忘记已保存的局域网并保持配置热点？'))return;try{const d=await fetchJson('/api/wifi/forget',{method:'POST',timeout:8000});setMessage('#wifiMessage',d.message,'ok')}catch(err){setMessage('#wifiMessage',err.message,'error')}});
$('#switchStaBtn').addEventListener('click',async()=>{if(!confirm('关闭配置热点并连接已保存的局域网？'))return;try{const d=await fetchJson('/api/network/sta',{method:'POST',timeout:8000});setMessage('#wifiMessage',d.message,'ok')}catch(err){setMessage('#wifiMessage','切换失败：'+err.message,'error')}});
$('#switchApBtn').addEventListener('click',async()=>{const apName=$('#apNameInput').value.trim()||lastStatus?.network?.ssid||'配置热点';if(!confirm(`关闭当前局域网连接并开启 ${apName}？`))return;try{const d=await fetchJson('/api/network/ap',{method:'POST',timeout:8000});setMessage('#wifiMessage',d.message,'ok')}catch(err){setMessage('#wifiMessage','切换失败：'+err.message,'error')}});
$('#saveDeviceBtn').addEventListener('click',async()=>{const deviceName=$('#deviceNameInput').value.trim(),hostname=$('#hostnameInput').value.trim().toLowerCase().replace(/\.local$/,''),apName=$('#apNameInput').value.trim();if(!deviceName||!hostname||!apName)return alert('设备名、主机名和热点名不能为空');if(!/^[a-z0-9](?:[a-z0-9-]{0,29}[a-z0-9])?$/.test(hostname))return alert('主机名只能包含小写字母、数字和连字符，且不能以连字符开头或结尾');if(!confirm(`保存设备身份？\n局域网地址将是 http://${hostname}.local/\n多块设备不能使用相同主机名。`))return;try{const body=new URLSearchParams({deviceName,hostname,apName,showInfo:$('#showInfoAfterIdentity').checked?'1':'0'});const d=await fetchJson('/api/device/save',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body,timeout:8000});identityFormTouched=false;alert(d.message)}catch(err){alert(err.message)}});


async function action(name){if(!confirm('确认执行一次全局刷新？\n两次全刷之间会自动冷却180秒。'))return;setBusy(true,'发送屏幕任务','任务保存后可关闭当前页面');try{const body=new URLSearchParams({action:name});const d=await fetchJson('/api/action',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body,timeout:30000});await pollStatus();alert(d.queued===false?'测试图与已显示画面相同，未重复刷新。':'任务已进入队列。')}catch(err){alert('操作失败：'+err.message)}finally{setBusy(false)}}
$$('.diag').forEach(b=>b.addEventListener('click',()=>action(b.dataset.action)));$('#rebootBtn').addEventListener('click',()=>{if(confirm('立即重启设备？'))fetchJson('/api/action',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({action:'reboot'}),timeout:5000}).catch(()=>{})});

initCalendarControls();drawCalendarSource();pollStatus();statusTimer=setInterval(pollStatus,2000);
