#!/usr/bin/env python3
"""Offline structural validation for the v1.2.0 source package."""
from __future__ import annotations

import gzip
import hashlib
import re
import shutil
import subprocess
import sys
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []
WARNINGS: list[str] = []


def require(condition: bool, message: str) -> None:
    if not condition:
        ERRORS.append(message)


def main() -> int:
    required = [
        "platformio.ini",
        "partitions_4mb.csv",
        "include/app_config.h",
        "include/lut_profiles.h",
        "include/web_ui.h",
        "include/epd_ssd2677_tb.h",
        "src/main.cpp",
        "src/epd_ssd2677_tb.cpp",
        "web/index.html",
        "tools/embed_web.py",
    ]
    for rel in required:
        require((ROOT / rel).is_file(), f"missing {rel}")

    require(not (ROOT / "host").exists(), "host/ must not exist")
    require(not (ROOT / "trmnl").exists(), "trmnl/ must not exist")

    text_files = []
    for path in ROOT.rglob("*"):
        if path == Path(__file__).resolve():
            continue
        if path.is_file() and path.suffix.lower() in {".cpp", ".h", ".html", ".js", ".py", ".ini", ".md", ".csv", ".bat", ".sh"}:
            text_files.append(path)
    runtime_files = [p for p in text_files if p.suffix.lower() in {".cpp", ".h", ".html", ".js", ".ini"}]
    combined = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in runtime_files)
    for forbidden in ["remoteUrl", "HTTPClient.h", "FastAPI", "Playwright", "current_frame.bin"]:
        require(forbidden not in combined, f"forbidden remote/server token remains in runtime files: {forbidden}")

    html = (ROOT / "web/index.html").read_text(encoding="utf-8")
    require("https://" not in html and "http://" not in html, "web UI contains an external URL")
    require("Floyd–Steinberg" in html, "web UI does not identify the fixed Floyd pipeline")
    require("FRAME_BYTES=153600" in html, "web frame length constant missing")
    require("packed[p>>2]|=codes[p]<<(6-((p&3)*2))" in html, "2bpp packing expression changed")

    lut_text = (ROOT / "include/lut_profiles.h").read_text(encoding="utf-8")
    arrays = re.findall(r"kE5Wsf1\[535\].*?\{(.*?)\};|kE5Wsf\[535\].*?\{(.*?)\};", lut_text, re.S)
    values = re.findall(r"0x([0-9A-Fa-f]{2})", lut_text)
    require(len(values) == 1072, f"expected 1070 LUT bytes plus two CRC literals, found {len(values)} hex tokens")
    w1_match = re.search(r"kE5Wsf1\[535\].*?\{(.*?)\};", lut_text, re.S)
    w3_match = re.search(r"kE5Wsf\[535\].*?\{(.*?)\};", lut_text, re.S)
    if w1_match and w3_match:
        w1 = bytes(int(x, 16) for x in re.findall(r"0x([0-9A-Fa-f]{2})", w1_match.group(1)))
        w3 = bytes(int(x, 16) for x in re.findall(r"0x([0-9A-Fa-f]{2})", w3_match.group(1)))
        require(len(w1) == 535, f"W1 length is {len(w1)}")
        require(len(w3) == 535, f"W3 length is {len(w3)}")
        require(zlib.crc32(w1) & 0xFFFFFFFF == 0xDEA3DF46, "W1 CRC mismatch")
        require(zlib.crc32(w3) & 0xFFFFFFFF == 0xE086FA09, "W3 CRC mismatch")
    else:
        ERRORS.append("unable to parse LUT arrays")

    header = (ROOT / "include/web_ui.h").read_text(encoding="utf-8")
    data_match = re.search(r"WEB_UI_GZ\[.*?\].*?\{(.*?)\};", header, re.S)
    sha_match = re.search(r'WEB_UI_SOURCE_SHA256\[\] = "([0-9a-f]{64})"', header)
    if data_match and sha_match:
        gz = bytes(int(x, 16) for x in re.findall(r"0x([0-9A-Fa-f]{2})", data_match.group(1)))
        decoded = gzip.decompress(gz)
        require(decoded == (ROOT / "web/index.html").read_bytes(), "embedded web UI is stale")
        require(hashlib.sha256(decoded).hexdigest() == sha_match.group(1), "embedded web SHA mismatch")
    else:
        ERRORS.append("unable to parse embedded web UI")

    node = shutil.which("node")
    if node:
        scripts = re.findall(r"<script>(.*?)</script>", html, re.S)
        if scripts:
            temp = ROOT / "tests" / "web-inline-check.js"
            temp.write_text(scripts[-1], encoding="utf-8")
            result = subprocess.run([node, "--check", str(temp)], capture_output=True, text=True)
            require(result.returncode == 0, "JavaScript syntax check failed: " + result.stderr.strip())
        else:
            ERRORS.append("inline script not found")
    else:
        WARNINGS.append("node not installed; JavaScript syntax check skipped")

    print(f"checked {len(text_files)} text files")
    for warning in WARNINGS:
        print("WARNING:", warning)
    for error in ERRORS:
        print("ERROR:", error)
    if ERRORS:
        return 1
    print("PASS: v1.2.0 structural validation")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
