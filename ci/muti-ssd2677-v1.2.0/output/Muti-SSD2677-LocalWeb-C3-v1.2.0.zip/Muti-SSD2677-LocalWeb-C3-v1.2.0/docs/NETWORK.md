# 网络状态机

## 启动

```text
有保存的 SSID → STA-only 连接 20 秒
                 ├─ 成功：局域网 + mDNS
                 └─ 失败：AP-only 配置热点
无保存的 SSID → AP-only 配置热点
```

默认配置热点：

```text
SSID：Muti-10.2
密码：无
IP：192.168.4.1
信道：6
最大客户端：4
```

Wi‑Fi 扫描期间会临时切换 AP+STA；扫描结束立即回到 AP-only。AP+STA 不作为长期运行模式。
