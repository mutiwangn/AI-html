"""Original educational digestive meshes. Blender 4.3. Browser JSON keeps Y-up/Z-front.
GLB is exported without coordinate conversion so numeric vertices agree with JSON.
Not a diagnostic model; relative tissue scale is exaggerated for young learners.
"""
import bpy, math, json
from mathutils import Vector, Matrix
from pathlib import Path
from math import sin,cos,pi
OUT=Path(__file__).parent
bpy.ops.wm.read_factory_settings(use_empty=True)
M={}; meshes=[]; variants={}
def mat(n,c):
 m=bpy.data.materials.new(n); m.diffuse_color=(*c,1); m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=.55
 M[n]=m;return m
for n,c in [('serosa',(.64,.23,.19)),('mucosa',(.87,.40,.35)),('fold',(.97,.58,.43)),('muscle',(.52,.15,.16)),('artery',(.85,.07,.09)),('vein',(.12,.36,.67)),('lacteal',(.49,.65,.19)),('amber',(.95,.64,.13))]:mat(n,c)
def mesh(n,v,f,m):
 d=bpy.data.meshes.new(n);d.from_pydata(v,[],f);d.update();o=bpy.data.objects.new(n,d);bpy.context.collection.objects.link(o);d.materials.append(M[m])
 for p in d.polygons:p.use_smooth=True
 meshes.append(o);return n

def tube(n,pts,r,m='fold',sides=8,half=False):
 pts=[Vector(p) for p in pts];vs=[];fs=[]
 for i,p in enumerate(pts):
  t=(pts[min(i+1,len(pts)-1)]-pts[max(i-1,0)]).normalized();ref=Vector((0,0,1))
  if abs(t.dot(ref))>.93:ref=Vector((1,0,0))
  a=t.cross(ref).normalized();b=t.cross(a).normalized()
  rr=r[i] if isinstance(r,list) else r
  for j in range(sides+1):
   th=(pi if half else 2*pi)*j/sides
   vs.append(tuple(p+rr*(cos(th)*a+sin(th)*b)))
 for i in range(len(pts)-1):
  for j in range(sides):q=i*(sides+1)+j;fs.append((q,q+1,q+sides+2,q+sides+1))
 return mesh(n,vs,fs,m)
def variant(n,objs,anchors):variants[n]={'objects':objs,'anchors':anchors}
# Stomach: broad asymmetric fundus and body; narrower antrum bends to pylorus.
# Ring centers along the long axis, full transverse width deliberately broad.
controls=[(-.64,1.85,.14,.13),(-.65,1.55,.16,.14),(-.57,1.30,.55,.40),(-.42,1.02,.82,.56),(-.28,.66,.91,.63),(-.18,.27,.89,.62),(-.08,-.12,.78,.55),(.14,-.43,.60,.44),(.48,-.55,.39,.30),(.80,-.45,.22,.21),(1.05,-.26,.15,.15)]
# Catmull-Rom interpolates only centers/radii; frames follow tangent.
def cat(ctrl,steps=4):
 out=[]
 for i in range(len(ctrl)-1):
  p0=Vector(ctrl[max(0,i-1)]);p1=Vector(ctrl[i]);p2=Vector(ctrl[i+1]);p3=Vector(ctrl[min(len(ctrl)-1,i+2)])
  for k in range(steps):
   t=k/steps;out.append(tuple(.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t)))
 out.append(ctrl[-1]);return out
rows=cat(controls,3)
def sac(n,front,m,scale=1):
 v=[];f=[];N=20
 for i,(x,y,r,d) in enumerate(rows):
  # transverse direction remains mostly horizontal for sac, turns at antrum
  prev=rows[max(0,i-1)];nex=rows[min(len(rows)-1,i+1)];t=Vector((nex[0]-prev[0],nex[1]-prev[1],0)).normalized();a=Vector((-t.y,t.x,0))
  for j in range(N+1):
   th=pi*j/N+(0 if front else pi);p=Vector((x,y,0))+a*r*scale*cos(th)+Vector((0,0,d*scale*sin(th)));v.append(tuple(p))
 for i in range(len(rows)-1):
  for j in range(N):q=i*(N+1)+j;f.append((q,q+1,q+N+2,q+N+1))
 return mesh(n,v,f,m)
back=sac('stomach_back_outer',False,'serosa');front=sac('stomach_front_outer',True,'serosa');inner=sac('stomach_back_mucosa',False,'mucosa',.93)
# Visible tissue thickness around the opened front half.
rv=[];rf=[]
for side in [-1,1]:
 start=len(rv)
 for i,(x,y,r,d) in enumerate(rows):
  prev=rows[max(0,i-1)];nex=rows[min(len(rows)-1,i+1)];t=Vector((nex[0]-prev[0],nex[1]-prev[1],0)).normalized();a=Vector((-t.y,t.x,0))
  for sc in [1,.93]:rv.append(tuple(Vector((x,y,0))+a*r*sc*side))
 for i in range(len(rows)-1):q=start+2*i;rf.append((q,q+2,q+3,q+1))
cutrim=mesh('stomach_cut_wall_thickness',rv,rf,'muscle')
duopts=[(1.04,-.26,0),(1.32,-.1,0),(1.53,-.30,0),(1.57,-.65,0),(1.38,-.95,0),(1.04,-1.02,0)]
duo=tube('duodenum_C_loop',cat(duopts,6),.14,'serosa',12)
folds=[]
for k in range(8):
 th=pi+.28+(pi-.56)*k/7;pts=[]
 for i in range(6,len(rows)-4):
  x,y,r,d=rows[i];prev=rows[i-1];nex=rows[i+1];t=Vector((nex[0]-prev[0],nex[1]-prev[1],0)).normalized();a=Vector((-t.y,t.x,0));tt=th+.055*sin(i*.86+k)
  p=Vector((x,y,0))+a*r*.91*cos(tt)+Vector((0,0,d*.90*sin(tt)+.035));pts.append(tuple(p))
 folds.append(tube('gastric_ruga_%02d'%k,pts,.035,'fold',6))
variant('stomach_outer',[back,front,duo],{'esophagus':[-.65,1.72,0],'stomach':[-.4,.5,.65],'pylorus':[1.0,-.25,.15],'duodenum':[1.55,-.6,.1]})
variant('stomach_cut',[back,inner,cutrim,duo]+folds,{'rugae':[-.3,.45,-.37],'lumen':[.15,.45,.0],'pylorus':[1.0,-.25,.15]})
# One continuous irregular, nonplanar small bowel. Rear loops recede in Z.
# Centerline clearance verified independently; radius .099 is below half minimum clearance.
pts=cat([[-0.72, 1.41, -0.03], [-1.23, 1.332, -0.03], [-1.41, 0.93, 0.0], [-1.14, 0.63, 0.03], [-0.69, 0.702, 0.03], [-0.48, 1.05, 0.012], [0.15, 1.11, -0.15], [0.84, 0.99, -0.18], [1.2, 0.69, -0.12], [0.93, 0.39, 0.06], [0.48, 0.48, 0.15], [0.09, 0.75, 0.18], [-0.27, 0.42, 0.24], [-1.02, 0.33, 0.3], [-1.23, -0.03, 0.36], [-0.93, -0.33, 0.39], [-0.39, -0.12, 0.42], [0.15, 0.18, 0.45], [0.75, 0.072, 0.39], [1.272, -0.06, 0.27], [1.188, -0.51, 0.15], [0.63, -0.66, 0.06], [0.36, -0.39, 0.15], [-0.06, -0.48, 0.18], [-0.6, -0.84, 0.21], [-1.116, -0.672, 0.15], [-1.278, -1.02, 0.09], [-0.72, -1.26, -0.09], [-0.09, -1.032, -0.09], [0.42, -0.9, -0.15], [0.9, -1.05, -0.24], [0.78, -1.38, -0.33], [0.18, -1.47, -0.39], [0.39, -1.152, -0.45], [1.11, -0.84, -0.45], [1.32, -0.3, -0.42], [0.93, -0.108, -0.39], [0.3, -0.57, -0.42], [-0.24, -0.99, -0.42], [-0.792, -1.05, -0.45], [-0.948, -0.564, -0.42], [-0.54, -0.432, -0.36], [0.06, -0.18, -0.39], [0.3, 0.228, -0.45], [-0.06, 0.468, -0.42], [-0.66, 0.09, -0.42], [-1.14, 0.084, -0.42], [-1.23, 0.528, -0.39], [-0.81, 0.93, -0.36], [-0.18, 0.732, -0.39], [0.36, 0.684, -0.39], [0.96, 1.14, -0.42], [1.38, 0.912, -0.36], [1.53, 0.33, -0.3], [1.56, -0.33, -0.21], [1.41, -1.032, -0.12], [0.99, -1.488, -0.06]],8)
bowel_flow=[list(p) for p in pts]
intest=tube('continuous_small_bowel',pts,.099,'serosa',10)
variant('intestine_outer',[intest],{'continuous_tube':[.1,.35,.2],'intestinal_wall':[-.8,-.15,.15]})
# Magnified lengthwise-open bowel segment, axis X. Back wall has semicircular lumen.
v=[];f=[];L=32;N=20
for i in range(L+1):
 x=-1.65+3.3*i/L
 for j in range(N+1):
  th=pi*j/N;v.append((x,.64*cos(th),-.64*sin(th)))
for i in range(L):
 for j in range(N):q=i*(N+1)+j;f.append((q,q+1,q+N+2,q+N+1))
section=mesh('bowel_longitudinal_back_wall',v,f,'mucosa');circ=[]
for k in range(12):
 x=-1.5+k*3/11;pts=[(x+.025*sin(j*.7),.57*cos(pi*j/20),-.57*sin(pi*j/20)+.02) for j in range(21)]
 circ.append(tube('circular_fold_%02d'%k,pts,.068,'fold',6))
rims=[]
for x in [-1.65,1.65]:rims.append(tube('bowel_cut_rim_'+str(x),[(x,.65*cos(pi*j/24),-.65*sin(pi*j/24)) for j in range(25)],.055,'muscle',6))
variant('intestine_cut',[section]+circ+rims,{'circular_folds':[0,.45,-.25],'lumen':[0,0,.12],'wall':[-1.65,-.5,-.35]})
# Villi grow out of an undulating mucosal sheet into the lumen, not floating rods.
v=[];f=[];N=18
for i in range(N+1):
 for j in range(N+1):
  x=-1.45+2.9*i/N;z=-.88+1.76*j/N;y=-.55+.06*cos(x*3)*cos(z*3);v.append((x,y,z))
for i in range(N):
 for j in range(N):q=i*(N+1)+j;f.append((q,q+1,q+N+2,q+N+1))
base=mesh('mucosal_patch',v,f,'mucosa');villi=[]
# Give the tissue tile physical depth with a connected sidewall.
edge=[v[i*(N+1)] for i in range(N+1)]+[v[N*(N+1)+j] for j in range(1,N+1)]+[v[i*(N+1)+N] for i in range(N-1,-1,-1)]+[v[j] for j in range(N-1,0,-1)]
sv=[];sf=[]
for x,y,z in edge:sv.extend([(x,y,z),(x,-.76,z)])
for i in range(len(edge)):q=2*i;nn=2*((i+1)%len(edge));sf.append((q,nn,nn+1,q+1))
sf.append(tuple(2*i+1 for i in range(len(edge))))
patch_sides=mesh('mucosal_patch_sides',sv,sf,'muscle')
def finger(n,x,z,h,r,half=False):
 vs=[];fs=[];N=12;R=20
 for i in range(R+1):
  t=i/R;rr=r*(.89+.12*sin(t*pi))*math.sqrt(max(.0002,1-(max(0,t-.72)/.28)**2));yy=-.51+h*t
  for j in range(N+1):
   th=(pi+pi*j/N) if half else 2*pi*j/N
   vs.append((x+rr*cos(th)+.07*sin(t*pi/2),yy,z+rr*sin(th)))
 for i in range(R):
  for j in range(N):q=i*(N+1)+j;fs.append((q,q+N+1,q+N+2,q+1))
 return mesh(n,vs,fs,'mucosa')
for i in range(7):
 for j in range(4):
  x=-1.22+i*.40+.04*(j%2);z=-.67+j*.43;h=.65+.18*(.5+.5*sin(i*2.3+j*1.1));villi.append(finger('villus_%02d_%02d'%(i,j),x,z,h,.13))
variant('villi_patch',[base,patch_sides]+villi,{'villus':[0,.28,.2],'mucosal_surface':[1,-.5,.6],'lumen':[0,.75,0]})
# A single enlarged villus, half-shell open toward +Z, central lymph lacteal and blood loops.
big=finger('large_villus_back_wall',-.07,0,2.9,.56,True)
# narrow outline on cut edges emphasizes that this is sectioned wall
outline=[]
for side in [-1,1]:
 pp=[]
 for i in range(25):
  t=i/24;r=.56*(.89+.12*sin(t*pi))*math.sqrt(max(.0002,1-(max(0,t-.72)/.28)**2));pp.append((-.07+side*r+.07*sin(t*pi/2),-.51+2.9*t,.02))
 outline.append(tube('villus_cut_edge_'+str(side),pp,.035,'fold',6))
lact=tube('central_lacteal',[(0,-.62,.06),(0,0,.06),(.01,.7,.06),(.03,1.4,.06),(.03,1.94,.06)], [.075,.075,.07,.06,.025],'lacteal',10)
vessels=[]
for side,ma in [(-1,'artery'),(1,'vein')]:
 pp=[(side*.32,-.7,.12),(side*.31,-.2,.13),(side*.28,.4,.14),(side*.25,1.0,.13),(side*.20,1.65,.1),(side*.11,2.06,.08)]
 vessels.append(tube('villus_'+ma+'_trunk',cat(pp,3),.038,ma,7))
for k in range(5):
 yy=-.05+k*.40;w=.28-.015*k
 pp=[(-w,yy,.13),(-w*.8,yy+.16,.23),(0,yy+.22,.26),(w*.8,yy+.16,.23),(w,yy,.13)]
 vessels.append(tube('capillary_loop_%02d'%k,cat(pp,3),.022,'artery' if k%2==0 else 'vein',6))
vessels.append(tube('apical_capillary_loop',[(-.11,2.06,.08),(-.06,2.18,.08),(.04,2.21,.08),(.11,2.06,.08)],.024,'artery',6))
variant('villi_cut',[big,lact]+outline+vessels,{'capillaries':[-.28,.8,.2],'lacteal':[0,1.5,.1],'epithelium':[.5,.5,.0],'blood_out':[.32,-.65,.12]})
variants['stomach_outer']['flowPath']=[[round(r[0],4),round(r[1],4),0] for r in rows]
variants['stomach_cut']['flowPath']=variants['stomach_outer']['flowPath']
variants['stomach_cut']['cavityCenter']=[-.2,.4,.0]
variants['stomach_cut']['cavityRadii']=[.48,.65,.25]
variants['intestine_outer']['flowPath']=bowel_flow
variants['intestine_cut']['flowPath']=[[-1.5,0,-.16],[0,0,-.16],[1.5,0,-.16]]
variants['villi_cut']['glucosePath']=[[-.55,.9,.15],[-.28,.9,.19],[-.10,1.0,.26],[.24,.85,.16],[.30,-.5,.14]]
# Export geometry, exact Blender vertex normals and mesh loop-triangle connectivity.
data={'version':2,'coordinateSystem':'Y-up, +Z front','materials':{},'meshes':[],'variants':variants}
for n,m in M.items():
 c=m.diffuse_color;srgb=lambda v:12.92*v if v<=.0031308 else 1.055*v**(1/2.4)-.055;data['materials'][n]={'color':'#'+''.join('%02x'%round(srgb(v)*255) for v in c[:3]),'linearRgb':[round(v,4) for v in c[:3]],'roughness':.55}
byname={o.name:o for o in meshes}
for o in meshes:
 d=o.data;d.calc_loop_triangles()
 data['meshes'].append({'name':o.name,'positions':[round(c,4) for v in d.vertices for c in v.co],'normals':[round(c,3) for v in d.vertices for c in v.normal],'indices':[int(i) for t in d.loop_triangles for i in t.vertices],'material':d.materials[0].name})
for n,var in variants.items():
 coords=[v.co for name in var['objects'] for v in byname[name].data.vertices]
 var['bounds']={'min':[round(min(v[k] for v in coords),4) for k in range(3)],'max':[round(max(v[k] for v in coords),4) for k in range(3)]}
 var['triangles']=sum(len(byname[name].data.loop_triangles) for name in var['objects'])
(OUT/'anatomy.json').write_text(json.dumps(data,separators=(',',':')))
# Keep each variant in its own Blender collection (shared mesh objects linked).
for n,var in variants.items():
 col=bpy.data.collections.new(n);bpy.context.scene.collection.children.link(col)
 for name in var['objects']:col.objects.link(byname[name])
for o in meshes:o.select_set(True)
bpy.context.view_layer.objects.active=meshes[0]
bpy.ops.export_scene.gltf(filepath=str(OUT/'digestive_anatomy.glb'),export_format='GLB',use_selection=True,export_yup=False,export_apply=True)
# Studio previews. Cameras/lights excluded from mesh exports.
scene=bpy.context.scene;scene.world=bpy.data.worlds.new('warm studio');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.92,.88,.81,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.45
bpy.ops.object.camera_add(location=(3,2,9));cam=bpy.context.object;cam.data.type='ORTHO';scene.camera=cam
for p,power,size in [((-3,5,5),600,5),((4,2,4),350,4),((0,3,-4),400,3)]:
 bpy.ops.object.light_add(type='AREA',location=p);l=bpy.context.object;l.data.energy=power;l.data.size=size;l.rotation_euler=(Vector((0,0,0))-l.location).to_track_quat('-Z','Y').to_euler()
scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=False
scene.render.resolution_x=720;scene.render.resolution_y=720;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX'
for n,center,pos,scale in [('stomach_cut',(0,.35,0),(2,1.3,9),4.3),('intestine_cut',(0,0,0),(2,2,8),4.3),('villi_cut',(0,.8,0),(2,1.7,9),3.8),('villi_patch',(0,-.05,0),(3,2.4,7),3.9),('intestine_outer',(0,.1,0),(1,1,9),3.6),('stomach_outer',(0,.35,0),(2,1.3,9),4.3)]:
 for o in meshes:o.hide_render=o.name not in variants[n]['objects']
 cam.location=pos;back=(cam.location-Vector(center)).normalized();right=Vector((0,1,0)).cross(back).normalized();up=back.cross(right);cam.rotation_euler=Matrix((right,up,back)).transposed().to_euler();cam.data.ortho_scale=scale
 scene.render.filepath=str(OUT/(n+'_preview.png'));bpy.ops.render.render(write_still=True)
for o in meshes:o.hide_render=o.name not in variants['stomach_cut']['objects']
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'digestive_anatomy.blend'))
report={'blender':bpy.app.version_string,'mesh_count':len(meshes),'vertices':sum(len(o.data.vertices) for o in meshes),'triangles':{n:v['triangles'] for n,v in variants.items()},'json_bytes':(OUT/'anatomy.json').stat().st_size,'glb_bytes':(OUT/'digestive_anatomy.glb').stat().st_size}
# Round-trip actual GLB import in new scene.
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(OUT/'digestive_anatomy.glb'))
report['reimported_meshes']=len([o for o in bpy.context.scene.objects if o.type=='MESH']);report['roundtrip_ok']=report['reimported_meshes']==report['mesh_count']
(OUT/'export_report.json').write_text(json.dumps(report,indent=2));print('ANATOMY_RESULT',json.dumps(report))
