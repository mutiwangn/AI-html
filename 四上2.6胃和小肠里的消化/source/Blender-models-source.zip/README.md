# Original Blender digestive anatomy models

These are original procedural educational meshes, authored and exported with Blender 4.3.2. They are simplified teaching models, not patient scans or medical reference reconstructions. Wall thickness, folds and blood vessels are enlarged to be legible to grade-four students. The villus view is a magnified schematic; the loop network is representative rather than a literal vascular reconstruction. Red/blue distinguish the blood network, and green distinguishes the central lymphatic lacteal. Glucose can be animated into blood; do not imply that all nutrients enter the blood directly.

## Files

- `build_anatomy.py`: complete repeatable Blender Python source. Run `blender -b -t 4 --python build_anatomy.py`.
- `digestive_anatomy.blend`: editable Blender file, named variant collections, lighting and preview camera.
- `digestive_anatomy.glb`: all actual mesh objects; variants spatially overlap by design, so filter by name/collection before display.
- `anatomy.json`: compact indexed triangles exported directly from Blender mesh vertices, normals, and loop triangles.
- `*_preview.png`: six actual Blender render previews, not AI imagery.
- `export_report.json`: byte counts, mesh count, per-variant triangles and actual GLB round-trip import result.

## Browser contract

Coordinates are **Y-up, +Z toward the viewer**, in scene-local arbitrary units. No extra 90-degree rotation is needed. GLB was exported with `export_yup=False` to preserve these coordinates. Every variant contains exact bounds and named label anchors. Fit camera from bounds, since enlarged villus and patch differ in center and scale.

`anatomy.json` top-level keys:

- `version`: 2.
- `coordinateSystem`: text.
- `materials`: dictionary keyed by material ID. Each has sRGB `color` (CSS hex), `linearRgb` triplet, and `roughness`. Use hex for Three.js `Color` constructor and CSS, or linearRgb only when your renderer explicitly expects linear colors. Do not apply gamma twice.
- `meshes`: objects with `name`, flattened XYZ `positions`, flattened XYZ smooth `normals`, integer triangle `indices`, and material ID `material`. Indexed normals are vertex normals from Blender. Set `DoubleSide` for cut views. Entire mesh JSON is geometry, not hand-authored SVG or images.
- `variants`: dictionary of six variants below. Each has `objects` (mesh-name list), `bounds: {min,max}`, `anchors` (XYZ positions), `triangles`, and optional motion paths.

## Variant / group mapping

- `stomach_outer`: stomach_front_outer + stomach_back_outer + duodenum_C_loop.
- `stomach_cut`: stomach_back_outer + stomach_back_mucosa + stomach_cut_wall_thickness + duodenum_C_loop + gastric_ruga_00 through gastric_ruga_07. Cutaway has front half removed and visible internal folds.
- `intestine_outer`: continuous_small_bowel, one continuous nonplanar curled tube. The centerline is also `flowPath`; the endpoint is not joined back to the start. No separate disconnected loops.
- `intestine_cut`: bowel_longitudinal_back_wall + circular_fold_00 through circular_fold_11 + bowel_cut_rim_-1.65 / bowel_cut_rim_1.65. Magnified longitudinally opened segment, not an entire flattened intestine. Circular fold arcs extend across the visible inner wall.
- `villi_patch`: mucosal_patch + mucosal_patch_sides + villus_00_00 through villus_06_03. Villi are raised 3D fingers growing from the tissue floor into the lumen.
- `villi_cut`: large_villus_back_wall + villus_cut_edge_-1 / villus_cut_edge_1 + central_lacteal + villus_artery_trunk + villus_vein_trunk + capillary_loop_00 through capillary_loop_04 + apical_capillary_loop. Front-open enlarged single villus.

## Animation guidance

Stomach variants have centerline `flowPath`, inlet to pylorus. `stomach_cut` adds `cavityCenter` and `cavityRadii` for small particles inside the lumen. Keep particles in the cutaway at Z near zero, above the back wall. Apply the same position-dependent deformation to the wall, rugae and cut edge, not independent object-scale pulses that detach folds. A subtle travelling displacement along Y can illustrate mixing without claiming exact physiology.

`intestine_cut.flowPath` runs along X at Y=0, Z=-0.16, in front of the inner wall. `intestine_outer.flowPath` is the actual full irregular centerline. Tube radius is 0.099 units. Centerline nonlocal sampled minimum clearance was 0.216, above its 0.198 diameter; compared with the previous reconstruction, thinner tube and separated rear loops prevent apparent/physical crossing. This is an educational coil layout rather than a fixed in-vivo position.

`villi_cut.glucosePath` enters from the lumen across the wall to a capillary and then follows the blue blood outflow. The green lacteal remains visible for anatomical completeness but is not the glucose destination. Smooth paths with Catmull-Rom or linear interpolation; mesh geometry itself is already triangulated.

## Anatomical references used by the lesson

- https://training.seer.cancer.gov/anatomy/digestive/regions/stomach.html
- https://training.seer.cancer.gov/anatomy/digestive/regions/intestine.html
- https://pathologia.ed.ac.uk/topic/gi-duodenum-and-small-bowel-normal-histology/

No third-party 3D meshes, scans, textures, or material assets are used. The irregular bowel centerline builds on the project's previous original teaching model and is resized with a reduced radius to avoid nonlocal collisions.
